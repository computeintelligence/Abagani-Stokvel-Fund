const TOGETHER_API_URL = "https://api.together.xyz/v1/chat/completions";
const MODEL = "meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo";

async function getApiKey(): Promise<string> {
  const key = process.env.TOGETHER_API_KEY;
  if (!key) {
    throw new Error("TOGETHER_API_KEY is not set. AI-generated messages are disabled. Set the TOGETHER_API_KEY secret to enable them.");
  }
  return key;
}

export async function generateMessage(prompt: string): Promise<string> {
  const apiKey = await getApiKey();

  const response = await fetch(TOGETHER_API_URL, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are a friendly and professional assistant for Abangani NS Group, a South African stokvel that helps parents save monthly for their children's school uniforms and stationery. Always respond in a warm, supportive, and culturally appropriate tone. Keep messages concise and clear. Use South African English. Currency is South African Rand (R).",
        },
        { role: "user", content: prompt },
      ],
      max_tokens: 500,
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error("Together AI error:", error);
    throw new Error(`Together AI API error: ${response.status}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || "Message could not be generated.";
}

export async function generateWelcomeMessage(memberName: string, trackingNumber: string, tier: string, monthlyAmount: number): Promise<string> {
  return generateMessage(
    `Generate a warm welcome message for a new member named ${memberName} who just registered for the ${tier} plan at R${monthlyAmount}/month. Their unique tracking number is ${trackingNumber}. Include their tracking number prominently and remind them to save it. Mention they will receive school uniforms and stationery for their children at the beginning of each year.`
  );
}

export async function generatePaymentConfirmation(memberName: string, amount: number, month: string, year: number): Promise<string> {
  return generateMessage(
    `Generate a payment confirmation message for ${memberName}. They paid R${amount} for ${month} ${year}. Thank them and encourage them to keep up the great work for their children's education.`
  );
}

export async function generatePaymentReminder(memberName: string, amount: number, overdueMonths: string[]): Promise<string> {
  return generateMessage(
    `Generate a gentle but firm payment reminder for ${memberName}. They owe R${amount} for the following months: ${overdueMonths.join(", ")}. Remind them that consistent payments ensure their children receive uniforms and stationery on time. Be encouraging, not threatening.`
  );
}

export async function generateCatchUpSummary(memberName: string, catchUpMonths: number, monthlyAmount: number, totalCatchUp: number): Promise<string> {
  return generateMessage(
    `Generate a message explaining the catch-up payment to ${memberName}. They are joining mid-year and need to pay for ${catchUpMonths} months of catch-up at R${monthlyAmount}/month, totaling R${totalCatchUp}. Explain that this ensures their children are included in the January distribution. Be supportive and understanding.`
  );
}
