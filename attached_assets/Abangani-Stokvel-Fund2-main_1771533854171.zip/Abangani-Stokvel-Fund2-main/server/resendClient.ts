import { Resend } from 'resend';

let connectionSettings: any;

async function getCredentials() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? 'repl ' + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
    ? 'depl ' + process.env.WEB_REPL_RENEWAL
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=resend',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  if (!connectionSettings || (!connectionSettings.settings.api_key)) {
    throw new Error('Resend not connected');
  }
  return { apiKey: connectionSettings.settings.api_key, fromEmail: connectionSettings.settings.from_email };
}

export async function getUncachableResendClient() {
  const { apiKey, fromEmail } = await getCredentials();
  return {
    client: new Resend(apiKey),
    fromEmail: fromEmail || 'onboarding@resend.dev'
  };
}

export async function sendEmail(to: string, subject: string, html: string) {
  try {
    const { client, fromEmail } = await getUncachableResendClient();
    const safeSender = fromEmail && !fromEmail.includes("gmail.com") && !fromEmail.includes("yahoo.com") && !fromEmail.includes("hotmail.com") && !fromEmail.includes("outlook.com")
      ? fromEmail
      : "onboarding@resend.dev";
    const result = await client.emails.send({
      from: `Abangani NS Group <${safeSender}>`,
      to: [to],
      subject,
      html,
    });
    if (result.error) {
      console.error("Email send error:", result.error);
    } else {
      console.log("Email sent successfully to:", to);
    }
    return result;
  } catch (error) {
    console.error("Failed to send email:", error);
    throw error;
  }
}
