const BRAND_COLOR = "#0d9488";
const BRAND_NAME = "Abangani NS Group";

function baseTemplate(content: string): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f5; color: #18181b; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; overflow: hidden; }
    .header { background: ${BRAND_COLOR}; padding: 32px 24px; text-align: center; }
    .header h1 { color: #ffffff; margin: 0; font-size: 24px; font-weight: 700; }
    .header p { color: rgba(255,255,255,0.85); margin: 8px 0 0; font-size: 14px; }
    .body { padding: 32px 24px; }
    .tracking-box { background: #f0fdfa; border: 2px solid ${BRAND_COLOR}; border-radius: 8px; padding: 16px; text-align: center; margin: 20px 0; }
    .tracking-box .label { font-size: 12px; text-transform: uppercase; letter-spacing: 1px; color: #6b7280; margin-bottom: 4px; }
    .tracking-box .number { font-size: 24px; font-weight: 700; color: ${BRAND_COLOR}; letter-spacing: 2px; }
    .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f4f4f5; }
    .info-label { color: #6b7280; font-size: 14px; }
    .info-value { font-weight: 600; font-size: 14px; }
    .btn { display: inline-block; background: ${BRAND_COLOR}; color: #ffffff; padding: 12px 32px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 14px; margin: 16px 0; }
    .footer { background: #f4f4f5; padding: 24px; text-align: center; font-size: 12px; color: #6b7280; }
    .divider { height: 1px; background: #e5e7eb; margin: 24px 0; }
    ul { padding-left: 20px; }
    li { margin-bottom: 8px; color: #374151; }
  </style>
</head>
<body>
  <div style="padding: 20px;">
    <div class="container">
      ${content}
      <div class="footer">
        <p>&copy; ${new Date().getFullYear()} ${BRAND_NAME}. All rights reserved.</p>
        <p>Stokvel Savings for School Uniforms & Stationery</p>
      </div>
    </div>
  </div>
</body>
</html>`;
}

export function welcomeEmailHtml(name: string, trackingNumber: string, tierName: string, monthlyAmount: number, registrationLink: string): string {
  return baseTemplate(`
    <div class="header">
      <h1>${BRAND_NAME}</h1>
      <p>Welcome to the Family</p>
    </div>
    <div class="body">
      <h2 style="margin-top:0;">Welcome, ${name}!</h2>
      <p>Thank you for joining ${BRAND_NAME}. We are thrilled to have you as part of our stokvel family. Together, we are building a brighter future for our children.</p>
      
      <div class="tracking-box">
        <div class="label">Your Tracking Number</div>
        <div class="number">${trackingNumber}</div>
      </div>
      <p style="text-align:center; font-size:13px; color:#6b7280;">Please save this number - you will need it to track your payments and membership.</p>

      <div class="divider"></div>

      <h3>Your Subscription Details</h3>
      <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
        <tr><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; color:#6b7280; font-size:14px;">Plan</td><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; font-weight:600; font-size:14px; text-align:right;">${tierName}</td></tr>
        <tr><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; color:#6b7280; font-size:14px;">Monthly Amount</td><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; font-weight:600; font-size:14px; text-align:right;">R${monthlyAmount}</td></tr>
      </table>

      <div style="text-align:center;">
        <a href="${registrationLink}" class="btn" style="color:#ffffff;">Go to Your Dashboard</a>
      </div>

      <div class="divider"></div>

      <h3>What Happens Next?</h3>
      <ul>
        <li>Make your monthly contributions on time</li>
        <li>Track your payments on your dashboard</li>
        <li>Your children receive school uniforms and full stationery at the start of each year</li>
      </ul>

      <p style="color:#6b7280; font-size:13px;">If you have any questions, please don't hesitate to reach out to us via our Contact page.</p>
    </div>
  `);
}

export function registrationSuccessEmailHtml(name: string, trackingNumber: string, tierName: string, monthlyAmount: number, childrenNames: string[]): string {
  return baseTemplate(`
    <div class="header">
      <h1>${BRAND_NAME}</h1>
      <p>Registration Confirmed</p>
    </div>
    <div class="body">
      <h2 style="margin-top:0;">Registration Complete!</h2>
      <p>Dear ${name}, your membership registration has been successfully processed. Here is a summary of your account:</p>
      
      <div class="tracking-box">
        <div class="label">Your Tracking Number</div>
        <div class="number">${trackingNumber}</div>
      </div>

      <h3>Membership Summary</h3>
      <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
        <tr><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; color:#6b7280; font-size:14px;">Plan</td><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; font-weight:600; font-size:14px; text-align:right;">${tierName}</td></tr>
        <tr><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; color:#6b7280; font-size:14px;">Monthly Amount</td><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; font-weight:600; font-size:14px; text-align:right;">R${monthlyAmount}</td></tr>
        <tr><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; color:#6b7280; font-size:14px;">Children</td><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; font-weight:600; font-size:14px; text-align:right;">${childrenNames.join(", ")}</td></tr>
      </table>

      <p>You can now log in to your dashboard to make payments and track your progress.</p>
      <p style="color:#6b7280; font-size:13px;">Keep this email for your records.</p>
    </div>
  `);
}

export function paymentSuccessEmailHtml(name: string, amount: number, month: string, year: number, trackingNumber: string): string {
  return baseTemplate(`
    <div class="header">
      <h1>${BRAND_NAME}</h1>
      <p>Payment Verified</p>
    </div>
    <div class="body">
      <h2 style="margin-top:0;">Payment Confirmed!</h2>
      <p>Dear ${name}, your payment has been verified and recorded successfully.</p>

      <table width="100%" cellpadding="0" cellspacing="0" style="margin:20px 0;">
        <tr><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; color:#6b7280; font-size:14px;">Amount</td><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; font-weight:600; font-size:14px; text-align:right;">R${amount}</td></tr>
        <tr><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; color:#6b7280; font-size:14px;">Period</td><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; font-weight:600; font-size:14px; text-align:right;">${month} ${year}</td></tr>
        <tr><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; color:#6b7280; font-size:14px;">Tracking #</td><td style="padding:8px 0; border-bottom:1px solid #f4f4f5; font-weight:600; font-size:14px; text-align:right;">${trackingNumber}</td></tr>
      </table>

      <p>Thank you for staying committed to your children's education. Every payment brings us closer to a brighter future.</p>
      <p style="color:#6b7280; font-size:13px;">Keep this email as your payment receipt.</p>
    </div>
  `);
}

export function supplierRegistrationEmailHtml(businessName: string, contactName: string): string {
  return baseTemplate(`
    <div class="header">
      <h1>${BRAND_NAME}</h1>
      <p>Supplier Application Received</p>
    </div>
    <div class="body">
      <h2 style="margin-top:0;">Application Received!</h2>
      <p>Dear ${contactName},</p>
      <p>Thank you for applying to become a supplier for ${BRAND_NAME}. We have received your application for <strong>${businessName}</strong>.</p>

      <div class="divider"></div>

      <h3>What Happens Next?</h3>
      <ul>
        <li>Our team will review your application within 5-7 business days</li>
        <li>We will verify your business details and pricing commitment</li>
        <li>You will receive an email once your application is approved</li>
      </ul>

      <p>If you have any questions about the process, please contact us through our website.</p>
      <p style="color:#6b7280; font-size:13px;">Thank you for your interest in supporting our community.</p>
    </div>
  `);
}
