import {
  type Member, type InsertMember, members,
  type Child, type InsertChild, children,
  type Payment, type InsertPayment, payments,
  type Notification, type InsertNotification, notifications,
  type Supplier, type InsertSupplier, suppliers,
  type User,
  adminSessions,
} from "@shared/schema";
import { users } from "@shared/models/auth";
import { db } from "./db";
import { eq, and, desc, sql, asc } from "drizzle-orm";
import { nanoid } from "nanoid";

export interface IStorage {
  getMember(id: string): Promise<Member | undefined>;
  getMemberByUserId(userId: string): Promise<Member | undefined>;
  getMemberByTracking(trackingNumber: string): Promise<Member | undefined>;
  createMember(member: InsertMember): Promise<Member>;
  updateMember(id: string, data: Partial<Member>): Promise<Member>;
  getAllMembers(): Promise<Member[]>;

  getChildrenByMember(memberId: string): Promise<Child[]>;
  createChild(child: InsertChild): Promise<Child>;
  deleteChildrenByMember(memberId: string): Promise<void>;

  getPaymentsByMember(memberId: string): Promise<Payment[]>;
  getPaymentByMonthYear(memberId: string, month: number, year: number): Promise<Payment | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: string, data: Partial<Payment>): Promise<Payment>;
  getAllPayments(): Promise<Payment[]>;
  getPendingPayments(): Promise<Payment[]>;
  getOverdueMembers(): Promise<Member[]>;

  getNotificationsByMember(memberId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<void>;

  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(data: { email: string; passwordHash: string; firstName: string; lastName: string }): Promise<User>;
  getAllUsers(): Promise<User[]>;

  createSupplier(supplier: InsertSupplier): Promise<Supplier>;
  getAllSuppliers(): Promise<Supplier[]>;
  getSupplier(id: string): Promise<Supplier | undefined>;
  updateSupplier(id: string, data: Partial<Supplier>): Promise<Supplier>;

  getChild(id: string): Promise<Child | undefined>;
  updateChild(id: string, data: Partial<Child>): Promise<Child>;
  getAllChildren(): Promise<Child[]>;
  deletePayment(id: string): Promise<void>;
}

class DatabaseStorage implements IStorage {
  async getMember(id: string): Promise<Member | undefined> {
    const [member] = await db.select().from(members).where(eq(members.id, id));
    return member;
  }

  async getMemberByUserId(userId: string): Promise<Member | undefined> {
    const [member] = await db.select().from(members).where(eq(members.userId, userId));
    return member;
  }

  async getMemberByTracking(trackingNumber: string): Promise<Member | undefined> {
    const [member] = await db.select().from(members).where(eq(members.trackingNumber, trackingNumber));
    return member;
  }

  async createMember(insertMember: InsertMember): Promise<Member> {
    const trackingNumber = `ABG-${new Date().getFullYear()}-${nanoid(8).toUpperCase()}`;
    const [member] = await db.insert(members).values({
      ...insertMember,
      trackingNumber,
    }).returning();
    return member;
  }

  async updateMember(id: string, data: Partial<Member>): Promise<Member> {
    const [member] = await db.update(members).set(data).where(eq(members.id, id)).returning();
    return member;
  }

  async getAllMembers(): Promise<Member[]> {
    return await db.select().from(members).orderBy(desc(members.createdAt));
  }

  async getChildrenByMember(memberId: string): Promise<Child[]> {
    return await db.select().from(children).where(eq(children.memberId, memberId));
  }

  async createChild(child: InsertChild): Promise<Child> {
    const [created] = await db.insert(children).values(child).returning();
    return created;
  }

  async deleteChildrenByMember(memberId: string): Promise<void> {
    await db.delete(children).where(eq(children.memberId, memberId));
  }

  async getPaymentsByMember(memberId: string): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.memberId, memberId)).orderBy(desc(payments.createdAt));
  }

  async getPaymentByMonthYear(memberId: string, month: number, year: number): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments).where(
      and(eq(payments.memberId, memberId), eq(payments.month, month), eq(payments.year, year))
    );
    return payment;
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [created] = await db.insert(payments).values(payment).returning();
    return created;
  }

  async updatePayment(id: string, data: Partial<Payment>): Promise<Payment> {
    const [updated] = await db.update(payments).set(data).where(eq(payments.id, id)).returning();
    return updated;
  }

  async getAllPayments(): Promise<Payment[]> {
    return await db.select().from(payments).orderBy(desc(payments.createdAt));
  }

  async getPendingPayments(): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.status, "pending")).orderBy(asc(payments.createdAt));
  }

  async getOverdueMembers(): Promise<Member[]> {
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();

    const allMembers = await db.select().from(members).where(eq(members.isActive, true));
    const overdueList: Member[] = [];

    for (const member of allMembers) {
      const memberPayments = await db.select().from(payments).where(
        and(eq(payments.memberId, member.id), eq(payments.status, "verified"))
      );
      const paidMonths = new Set(memberPayments.map(p => `${p.year}-${p.month}`));

      let startMonth = member.registrationMonth;
      let startYear = member.registrationYear;

      for (let y = startYear; y <= currentYear; y++) {
        const mStart = y === startYear ? startMonth : 1;
        const mEnd = y === currentYear ? currentMonth : 12;
        for (let m = mStart; m <= mEnd; m++) {
          if (!paidMonths.has(`${y}-${m}`)) {
            overdueList.push(member);
            break;
          }
        }
        if (overdueList.includes(member)) break;
      }
    }

    return overdueList;
  }

  async getNotificationsByMember(memberId: string): Promise<Notification[]> {
    return await db.select().from(notifications).where(eq(notifications.memberId, memberId)).orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [created] = await db.insert(notifications).values(notification).returning();
    return created;
  }

  async markNotificationRead(id: string): Promise<void> {
    await db.update(notifications).set({ read: true }).where(eq(notifications.id, id));
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(data: { email: string; passwordHash: string; firstName: string; lastName: string }): Promise<User> {
    const [user] = await db.insert(users).values({
      email: data.email,
      passwordHash: data.passwordHash,
      firstName: data.firstName,
      lastName: data.lastName,
    }).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createSupplier(supplier: InsertSupplier): Promise<Supplier> {
    const [created] = await db.insert(suppliers).values(supplier).returning();
    return created;
  }

  async getAllSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers).orderBy(desc(suppliers.createdAt));
  }

  async getSupplier(id: string): Promise<Supplier | undefined> {
    const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    return supplier;
  }

  async updateSupplier(id: string, data: Partial<Supplier>): Promise<Supplier> {
    const [updated] = await db.update(suppliers).set(data).where(eq(suppliers.id, id)).returning();
    return updated;
  }

  async getChild(id: string): Promise<Child | undefined> {
    const [child] = await db.select().from(children).where(eq(children.id, id));
    return child;
  }

  async updateChild(id: string, data: Partial<Child>): Promise<Child> {
    const [updated] = await db.update(children).set(data).where(eq(children.id, id)).returning();
    return updated;
  }

  async getAllChildren(): Promise<Child[]> {
    return await db.select().from(children);
  }

  async deletePayment(id: string): Promise<void> {
    await db.delete(payments).where(eq(payments.id, id));
  }
}

export const storage = new DatabaseStorage();
