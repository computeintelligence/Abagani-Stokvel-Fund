import { getUncachableStripeClient } from './stripeClient';

async function seedProducts() {
  const stripe = await getUncachableStripeClient();

  const tiers = [
    {
      name: "Primary School",
      description: "School uniforms and full stationery for primary school learners",
      amount: 17500,
      metadata: { tier: "primary" },
    },
    {
      name: "High School",
      description: "School uniforms and full stationery for high school learners",
      amount: 27500,
      metadata: { tier: "high_school" },
    },
    {
      name: "Cashback",
      description: "Premium plan with cashback benefits for school supplies",
      amount: 60000,
      metadata: { tier: "cashback" },
    },
  ];

  for (const tier of tiers) {
    const existing = await stripe.products.search({ query: `name:'${tier.name}'` });
    if (existing.data.length > 0) {
      console.log(`${tier.name} already exists, skipping...`);
      continue;
    }

    const product = await stripe.products.create({
      name: tier.name,
      description: tier.description,
      metadata: tier.metadata,
    });

    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: tier.amount,
      currency: 'zar',
      recurring: { interval: 'month' },
    });

    console.log(`Created ${tier.name}: product=${product.id}, price=${price.id}`);
  }

  console.log('Done seeding products!');
}

seedProducts().catch(console.error);
