import type { Express, RequestHandler } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMemberSchema, insertChildSchema, insertPaymentSchema } from "@shared/schema";
import { TIER_PRICES, MONTH_NAMES as MONTH_NAMES_CONST, PAYMENT_START_DATE } from "@shared/constants";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { generateWelcomeMessage, generatePaymentConfirmation, generateCatchUpSummary } from "./togetherAI";
import { getUncachableGoogleSheetClient, getGoogleDriveClient } from "./googleSheetsClient";
import { sendEmailViaGmail as sendEmail } from "./gmailClient";
import { welcomeEmailHtml, registrationSuccessEmailHtml, paymentSuccessEmailHtml, supplierRegistrationEmailHtml } from "./emailTemplates";
import multer from "multer";
import { Client } from "@replit/object-storage";
import PDFDocument from "pdfkit";
import { Parser } from "json2csv";

const ADMIN_CODE_HASH = bcrypt.hashSync("ABANGANI26", 10);

let objectStorageClient: Client | null = null;
function getObjectStorageClient(): Client {
  if (!objectStorageClient) {
    objectStorageClient = new Client();
  }
  return objectStorageClient;
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowedMimes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
      "application/pdf",
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only image files and PDFs are allowed"));
    }
  },
});

function calculateCatchUp(registrationMonth: number, monthlyAmount: number): { catchUpMonths: number; catchUpAmount: number } {
  const catchUpMonths = registrationMonth - 1;
  return {
    catchUpMonths,
    catchUpAmount: catchUpMonths * monthlyAmount,
  };
}

const MONTH_NAMES = MONTH_NAMES_CONST;

const isAuthenticated: RequestHandler = (req, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
};

const isAdminAuthenticated: RequestHandler = (req, res, next) => {
  if (req.session.adminAuthenticated !== true) {
    return res.status(401).json({ message: "Admin authentication required" });
  }
  next();
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  const signupSchema = z.object({
    email: z.string().email(),
    password: z.string().min(6),
    firstName: z.string().min(1),
    lastName: z.string().min(1),
  });

  const loginSchema = z.object({
    email: z.string().email(),
    password: z.string().min(1),
  });

  app.post("/api/auth/signup", async (req, res) => {
    try {
      const data = signupSchema.parse(req.body);
      const existing = await storage.getUserByEmail(data.email);
      if (existing) {
        return res.status(400).json({ message: "An account with this email already exists" });
      }

      const passwordHash = await bcrypt.hash(data.password, 10);
      const user = await storage.createUser({
        email: data.email,
        passwordHash,
        firstName: data.firstName,
        lastName: data.lastName,
      });

      req.session.userId = user.id;

      try {
        await sendEmail(
          data.email,
          "Welcome to Abangani NS Group!",
          welcomeEmailHtml(
            `${data.firstName} ${data.lastName}`,
            "Not yet assigned",
            "Not yet selected",
            0,
            `${req.protocol}://${req.hostname}/register`
          )
        );
      } catch (emailError) {
        console.error("Welcome email failed:", emailError);
      }

      const { passwordHash: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0]?.message || "Invalid input" });
      }
      console.error("Signup error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      const user = await storage.getUserByEmail(data.email);
      if (!user || !user.passwordHash) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const valid = await bcrypt.compare(data.password, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      req.session.userId = user.id;
      const { passwordHash: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0]?.message || "Invalid input" });
      }
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      res.json({ success: true });
    });
  });

  app.get("/api/auth/user", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });
      const member = await storage.getMemberByUserId(userId);
      const { passwordHash: _, ...safeUser } = user;
      res.json({ ...safeUser, member });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/tiers", (_req, res) => {
    res.json(TIER_PRICES);
  });

  app.post("/api/catch-up/calculate", (req, res) => {
    const { tier, registrationMonth } = req.body;
    const tierInfo = TIER_PRICES[tier];
    if (!tierInfo) return res.status(400).json({ message: "Invalid tier" });
    const result = calculateCatchUp(registrationMonth, tierInfo.amount);
    res.json({ ...result, monthlyAmount: tierInfo.amount, tierName: tierInfo.name });
  });

  app.post("/api/register", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);

      const existing = await storage.getMemberByUserId(userId);
      if (existing) return res.status(400).json({ message: "Already registered" });

      const { parent, children: childrenData, tier, agreedToTerms } = req.body;

      const tierInfo = TIER_PRICES[tier];
      if (!tierInfo) return res.status(400).json({ message: "Invalid tier" });

      const now = new Date();
      const registrationMonth = now.getMonth() + 1;
      const registrationYear = now.getFullYear();
      const { catchUpAmount } = calculateCatchUp(registrationMonth, tierInfo.amount);

      const member = await storage.createMember({
        userId,
        fullName: parent.fullName,
        phone: parent.phone,
        address: parent.address || null,
        tier,
        monthlyAmount: tierInfo.amount,
        registrationMonth,
        registrationYear,
        agreedToTerms: agreedToTerms || false,
      });

      await storage.updateMember(member.id, { catchUpAmount });

      const childrenNames: string[] = [];
      if (childrenData && Array.isArray(childrenData)) {
        for (const child of childrenData) {
          await storage.createChild({
            memberId: member.id,
            fullName: child.fullName,
            school: child.school,
            grade: child.grade,
            uniformSize: child.uniformSize || null,
            shoeSize: child.shoeSize || null,
          });
          childrenNames.push(child.fullName);
        }
      }

      try {
        const welcomeMsg = await generateWelcomeMessage(
          parent.fullName, member.trackingNumber, tierInfo.name, tierInfo.amount
        );
        await storage.createNotification({
          memberId: member.id,
          type: "welcome",
          message: welcomeMsg,
        });
      } catch (aiError) {
        console.error("AI message generation failed:", aiError);
        await storage.createNotification({
          memberId: member.id,
          type: "welcome",
          message: `Welcome to Abangani NS Group, ${parent.fullName}! Your tracking number is ${member.trackingNumber}. Please save it for your records. Your ${tierInfo.name} subscription is R${tierInfo.amount}/month.`,
        });
      }

      if (user?.email) {
        try {
          await sendEmail(
            user.email,
            `Registration Successful - ${member.trackingNumber}`,
            registrationSuccessEmailHtml(
              parent.fullName,
              member.trackingNumber,
              tierInfo.name,
              tierInfo.amount,
              childrenNames
            )
          );
        } catch (emailError) {
          console.error("Registration email failed:", emailError);
        }
      }

      const updatedMember = await storage.getMember(member.id);
      const memberChildren = await storage.getChildrenByMember(member.id);

      res.json({ member: updatedMember, children: memberChildren });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.get("/api/member/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const member = await storage.getMemberByUserId(userId);
      if (!member) return res.status(404).json({ message: "Member not found" });
      const memberChildren = await storage.getChildrenByMember(member.id);
      const memberPayments = await storage.getPaymentsByMember(member.id);
      res.json({ member, children: memberChildren, payments: memberPayments });
    } catch (error) {
      console.error("Profile fetch error:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.get("/api/member/payment-status", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const member = await storage.getMemberByUserId(userId);
      if (!member) return res.status(404).json({ message: "Member not found" });

      const now = new Date();
      const currentMonth = now.getMonth() + 1;
      const currentYear = now.getFullYear();
      const memberPayments = await storage.getPaymentsByMember(member.id);

      const paidMonths = new Set(
        memberPayments.filter(p => p.status === "verified").map(p => `${p.year}-${p.month}`)
      );
      const pendingMonths = new Set(
        memberPayments.filter(p => p.status === "pending").map(p => `${p.year}-${p.month}`)
      );

      const months: { month: number; year: number; name: string; status: string }[] = [];
      for (let y = member.registrationYear; y <= currentYear; y++) {
        const mStart = 1;
        const mEnd = y === currentYear ? currentMonth : 12;
        for (let m = mStart; m <= mEnd; m++) {
          const key = `${y}-${m}`;
          months.push({
            month: m,
            year: y,
            name: MONTH_NAMES[m - 1],
            status: paidMonths.has(key) ? "paid" : pendingMonths.has(key) ? "pending" : "unpaid",
          });
        }
      }

      const totalDue = months.length * member.monthlyAmount;
      const totalPaid = memberPayments.filter(p => p.status === "verified").reduce((sum, p) => sum + p.amount, 0);
      const progress = totalDue > 0 ? Math.min(100, Math.round((totalPaid / totalDue) * 100)) : 0;

      res.json({ months, totalDue, totalPaid, progress, monthlyAmount: member.monthlyAmount, catchUpAmount: member.catchUpAmount, catchUpPaid: member.catchUpPaid });
    } catch (error) {
      console.error("Payment status error:", error);
      res.status(500).json({ message: "Failed to fetch payment status" });
    }
  });

  app.post("/api/payments", isAuthenticated, async (req, res) => {
    try {
      if (new Date() < PAYMENT_START_DATE) {
        return res.status(400).json({ message: "Payments will be available from 10 March 2026" });
      }

      const userId = req.session.userId!;
      const member = await storage.getMemberByUserId(userId);
      if (!member) return res.status(404).json({ message: "Member not found" });

      const { amount, month, year, method, reference, proofUrl, isCatchUp } = req.body;

      const payment = await storage.createPayment({
        memberId: member.id,
        amount,
        month,
        year,
        method: method || "bank_transfer",
        reference: reference || null,
        proofUrl: proofUrl || null,
        isCatchUp: isCatchUp || false,
        status: "pending",
      });

      res.json(payment);
    } catch (error) {
      console.error("Payment creation error:", error);
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  app.get("/api/notifications", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const member = await storage.getMemberByUserId(userId);
      if (!member) return res.json([]);
      const notifs = await storage.getNotificationsByMember(member.id);
      res.json(notifs);
    } catch (error) {
      console.error("Notifications error:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    try {
      await storage.markNotificationRead(req.params.id as string);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark notification read" });
    }
  });

  app.post("/api/suppliers/register", async (req, res) => {
    try {
      const {
        contactFirstName, contactLastName, contactEmail, contactPhone,
        businessName, businessType, businessRegistrationNumber, businessAddress,
        city, province, productsOffered, agreedToLowPrices, agreedToTerms,
      } = req.body;

      if (!contactFirstName || !contactLastName || !contactEmail || !contactPhone ||
          !businessName || !businessType || !businessAddress || !city || !province ||
          !productsOffered || !agreedToLowPrices || !agreedToTerms) {
        return res.status(400).json({ message: "All required fields must be completed" });
      }

      const supplier = await storage.createSupplier({
        contactFirstName,
        contactLastName,
        contactEmail,
        contactPhone,
        businessName,
        businessType,
        businessRegistrationNumber: businessRegistrationNumber || null,
        businessAddress,
        city,
        province,
        productsOffered,
        agreedToLowPrices,
        agreedToTerms,
      });

      try {
        await sendEmail(
          contactEmail,
          "Supplier Application Received - Abangani NS Group",
          supplierRegistrationEmailHtml(businessName, `${contactFirstName} ${contactLastName}`)
        );
      } catch (emailError) {
        console.error("Supplier email failed:", emailError);
      }

      res.json(supplier);
    } catch (error) {
      console.error("Supplier registration error:", error);
      res.status(500).json({ message: "Supplier registration failed" });
    }
  });

  app.post("/api/upload/proof", isAuthenticated, upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const privateDir = process.env.PRIVATE_OBJECT_DIR || "";
      const ext = req.file.originalname.split(".").pop() || "bin";
      const filename = `proof_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
      const objectPath = privateDir ? `${privateDir}/uploads/${filename}` : `uploads/${filename}`;

      await getObjectStorageClient().uploadFromBytes(objectPath, req.file.buffer);

      res.json({ url: objectPath });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  app.post("/api/admin/login", async (req, res) => {
    try {
      const { code } = req.body;
      if (!code) {
        return res.status(400).json({ message: "Access code is required" });
      }

      const valid = await bcrypt.compare(code, ADMIN_CODE_HASH);
      if (!valid) {
        return res.status(401).json({ message: "Invalid access code" });
      }

      req.session.adminAuthenticated = true;
      res.json({ authenticated: true });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ message: "Admin login failed" });
    }
  });

  app.get("/api/admin/session", (req, res) => {
    res.json({ authenticated: req.session.adminAuthenticated === true });
  });

  app.post("/api/admin/logout", (req, res) => {
    req.session.adminAuthenticated = undefined;
    res.json({ success: true });
  });

  app.get("/api/admin/members", isAdminAuthenticated, async (req, res) => {
    try {
      const allMembers = await storage.getAllMembers();
      const membersWithChildren = await Promise.all(
        allMembers.map(async (m) => {
          const ch = await storage.getChildrenByMember(m.id);
          return { ...m, children: ch };
        })
      );
      res.json(membersWithChildren);
    } catch (error) {
      console.error("Admin members error:", error);
      res.status(500).json({ message: "Failed to fetch members" });
    }
  });

  app.put("/api/admin/members/:id", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const member = await storage.getMember(id);
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }

      const allowedFields = [
        "fullName", "phone", "address", "tier", "monthlyAmount",
        "isActive", "catchUpAmount", "catchUpPaid",
      ];
      const updateData: Record<string, any> = {};
      for (const field of allowedFields) {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      }

      const updated = await storage.updateMember(id, updateData);
      res.json(updated);
    } catch (error) {
      console.error("Admin member update error:", error);
      res.status(500).json({ message: "Failed to update member" });
    }
  });

  app.get("/api/admin/payments", isAdminAuthenticated, async (_req, res) => {
    try {
      const allPayments = await storage.getAllPayments();
      res.json(allPayments);
    } catch (error) {
      console.error("Admin payments error:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  app.get("/api/admin/pending-payments", isAdminAuthenticated, async (_req, res) => {
    try {
      const pending = await storage.getPendingPayments();
      const enriched = await Promise.all(
        pending.map(async (p) => {
          const member = await storage.getMember(p.memberId);
          return { ...p, memberName: member?.fullName || "Unknown" };
        })
      );
      res.json(enriched);
    } catch (error) {
      console.error("Pending payments error:", error);
      res.status(500).json({ message: "Failed to fetch pending payments" });
    }
  });

  app.post("/api/admin/payments/:id/verify", isAdminAuthenticated, async (req, res) => {
    try {
      const { status } = req.body;
      if (!["verified", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      const payment = await storage.updatePayment(req.params.id as string, {
        status,
        verifiedAt: status === "verified" ? new Date() : null,
      });

      if (status === "verified") {
        const member = await storage.getMember(payment.memberId);
        if (member) {
          try {
            const confirmMsg = await generatePaymentConfirmation(
              member.fullName, payment.amount, MONTH_NAMES[payment.month - 1], payment.year
            );
            await storage.createNotification({
              memberId: member.id,
              type: "payment_confirmed",
              message: confirmMsg,
            });
          } catch {
            await storage.createNotification({
              memberId: member.id,
              type: "payment_confirmed",
              message: `Your payment of R${payment.amount} for ${MONTH_NAMES[payment.month - 1]} ${payment.year} has been verified. Thank you, ${member.fullName}!`,
            });
          }

          const user = await storage.getUser(member.userId);
          if (user?.email) {
            try {
              await sendEmail(
                user.email,
                `Payment Verified - R${payment.amount} for ${MONTH_NAMES[payment.month - 1]} ${payment.year}`,
                paymentSuccessEmailHtml(
                  member.fullName,
                  payment.amount,
                  MONTH_NAMES[payment.month - 1],
                  payment.year,
                  member.trackingNumber
                )
              );
            } catch (emailError) {
              console.error("Payment success email failed:", emailError);
            }
          }
        }
      }

      res.json(payment);
    } catch (error) {
      console.error("Payment verify error:", error);
      res.status(500).json({ message: "Failed to verify payment" });
    }
  });

  app.get("/api/admin/overdue", isAdminAuthenticated, async (_req, res) => {
    try {
      const overdue = await storage.getOverdueMembers();
      res.json(overdue);
    } catch (error) {
      console.error("Overdue members error:", error);
      res.status(500).json({ message: "Failed to fetch overdue members" });
    }
  });

  app.get("/api/admin/stats", isAdminAuthenticated, async (_req, res) => {
    try {
      const allMembers = await storage.getAllMembers();
      const allPayments = await storage.getAllPayments();

      const totalMembers = allMembers.length;
      const activeMembers = allMembers.filter(m => m.isActive).length;
      const totalRevenue = allPayments.filter(p => p.status === "verified").reduce((sum, p) => sum + p.amount, 0);
      const pendingPayments = allPayments.filter(p => p.status === "pending").length;

      const tierBreakdown = {
        primary: allMembers.filter(m => m.tier === "primary").length,
        high_school: allMembers.filter(m => m.tier === "high_school").length,
        cashback: allMembers.filter(m => m.tier === "cashback").length,
      };

      res.json({ totalMembers, activeMembers, totalRevenue, pendingPayments, tierBreakdown });
    } catch (error) {
      console.error("Stats error:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get("/api/admin/suppliers", isAdminAuthenticated, async (_req, res) => {
    try {
      const allSuppliers = await storage.getAllSuppliers();
      res.json(allSuppliers);
    } catch (error) {
      console.error("Suppliers error:", error);
      res.status(500).json({ message: "Failed to fetch suppliers" });
    }
  });

  app.post("/api/admin/suppliers/:id/status", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      if (!["pending", "approved", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status. Must be pending, approved, or rejected" });
      }

      const supplier = await storage.getSupplier(id);
      if (!supplier) {
        return res.status(404).json({ message: "Supplier not found" });
      }

      const updated = await storage.updateSupplier(id, { status });
      res.json(updated);
    } catch (error) {
      console.error("Supplier status update error:", error);
      res.status(500).json({ message: "Failed to update supplier status" });
    }
  });

  app.get("/api/admin/export-csv", isAdminAuthenticated, async (_req, res) => {
    try {
      const allMembers = await storage.getAllMembers();
      const allPayments = await storage.getAllPayments();
      const allChildren = await storage.getAllChildren();

      const memberRows = allMembers.map(m => ({
        ID: m.id,
        TrackingNumber: m.trackingNumber,
        FullName: m.fullName,
        Phone: m.phone,
        Address: m.address || "",
        Tier: TIER_PRICES[m.tier]?.name || m.tier,
        MonthlyAmount: m.monthlyAmount,
        RegistrationMonth: m.registrationMonth,
        RegistrationYear: m.registrationYear,
        CatchUpAmount: m.catchUpAmount,
        CatchUpPaid: m.catchUpPaid ? "Yes" : "No",
        Active: m.isActive ? "Yes" : "No",
        CreatedAt: m.createdAt?.toISOString() || "",
      }));

      const childRows = allChildren.map(c => ({
        ID: c.id,
        MemberID: c.memberId,
        FullName: c.fullName,
        School: c.school,
        Grade: c.grade,
        UniformSize: c.uniformSize || "",
        ShoeSize: c.shoeSize || "",
      }));

      const paymentRows = allPayments.map(p => ({
        ID: p.id,
        MemberID: p.memberId,
        Amount: p.amount,
        Month: MONTH_NAMES[(p.month || 1) - 1],
        Year: p.year,
        Status: p.status,
        Method: p.method,
        Reference: p.reference || "",
        IsCatchUp: p.isCatchUp ? "Yes" : "No",
        CreatedAt: p.createdAt?.toISOString() || "",
      }));

      let csvContent = "=== MEMBERS ===\n";
      if (memberRows.length > 0) {
        const memberParser = new Parser();
        csvContent += memberParser.parse(memberRows);
      } else {
        csvContent += "No members found";
      }

      csvContent += "\n\n=== CHILDREN ===\n";
      if (childRows.length > 0) {
        const childParser = new Parser();
        csvContent += childParser.parse(childRows);
      } else {
        csvContent += "No children found";
      }

      csvContent += "\n\n=== PAYMENTS ===\n";
      if (paymentRows.length > 0) {
        const paymentParser = new Parser();
        csvContent += paymentParser.parse(paymentRows);
      } else {
        csvContent += "No payments found";
      }

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="abangani_export_${new Date().toISOString().split("T")[0]}.csv"`);
      res.send(csvContent);
    } catch (error) {
      console.error("CSV export error:", error);
      res.status(500).json({ message: "Failed to export CSV" });
    }
  });

  app.get("/api/admin/members/:id/pdf", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const member = await storage.getMember(id);
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }

      const memberChildren = await storage.getChildrenByMember(id);
      const memberPayments = await storage.getPaymentsByMember(id);
      const tierInfo = TIER_PRICES[member.tier];

      const doc = new PDFDocument({ margin: 50 });

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="member_${member.trackingNumber}.pdf"`);
      doc.pipe(res);

      doc.fontSize(22).font("Helvetica-Bold").text("Abangani NS Group", { align: "center" });
      doc.fontSize(14).font("Helvetica").text("Member Report", { align: "center" });
      doc.moveDown(0.5);
      doc.fontSize(10).fillColor("#666666").text(`Generated: ${new Date().toLocaleDateString("en-ZA")}`, { align: "center" });
      doc.fillColor("#000000");
      doc.moveDown(1);

      doc.moveTo(50, doc.y).lineTo(545, doc.y).strokeColor("#cccccc").stroke();
      doc.moveDown(1);

      doc.fontSize(16).font("Helvetica-Bold").text("Member Details");
      doc.moveDown(0.5);
      doc.fontSize(11).font("Helvetica");

      const details = [
        ["Tracking Number", member.trackingNumber],
        ["Full Name", member.fullName],
        ["Phone", member.phone],
        ["Address", member.address || "Not provided"],
        ["Tier", tierInfo?.name || member.tier],
        ["Monthly Amount", `R${member.monthlyAmount}`],
        ["Registration", `${MONTH_NAMES[member.registrationMonth - 1]} ${member.registrationYear}`],
        ["Catch-Up Amount", `R${member.catchUpAmount}`],
        ["Catch-Up Paid", member.catchUpPaid ? "Yes" : "No"],
        ["Status", member.isActive ? "Active" : "Inactive"],
      ];

      for (const [label, value] of details) {
        doc.font("Helvetica-Bold").text(`${label}: `, { continued: true });
        doc.font("Helvetica").text(String(value));
      }

      doc.moveDown(1);
      doc.moveTo(50, doc.y).lineTo(545, doc.y).strokeColor("#cccccc").stroke();
      doc.moveDown(1);

      doc.fontSize(16).font("Helvetica-Bold").text("Children");
      doc.moveDown(0.5);

      if (memberChildren.length === 0) {
        doc.fontSize(11).font("Helvetica").text("No children registered.");
      } else {
        for (let i = 0; i < memberChildren.length; i++) {
          const child = memberChildren[i];
          doc.fontSize(12).font("Helvetica-Bold").text(`Child ${i + 1}: ${child.fullName}`);
          doc.fontSize(11).font("Helvetica");
          doc.text(`  School: ${child.school}`);
          doc.text(`  Grade: ${child.grade}`);
          if (child.uniformSize) doc.text(`  Uniform Size: ${child.uniformSize}`);
          if (child.shoeSize) doc.text(`  Shoe Size: ${child.shoeSize}`);
          doc.moveDown(0.3);
        }
      }

      doc.moveDown(0.5);
      doc.moveTo(50, doc.y).lineTo(545, doc.y).strokeColor("#cccccc").stroke();
      doc.moveDown(1);

      doc.fontSize(16).font("Helvetica-Bold").text("Payment History");
      doc.moveDown(0.5);

      if (memberPayments.length === 0) {
        doc.fontSize(11).font("Helvetica").text("No payments recorded.");
      } else {
        const tableTop = doc.y;
        const colWidths = [80, 80, 80, 80, 100, 75];
        const headers = ["Amount", "Month", "Year", "Status", "Method", "Catch-Up"];

        doc.fontSize(10).font("Helvetica-Bold");
        let xPos = 50;
        for (let i = 0; i < headers.length; i++) {
          doc.text(headers[i], xPos, tableTop, { width: colWidths[i] });
          xPos += colWidths[i];
        }

        doc.moveDown(0.5);
        doc.moveTo(50, doc.y).lineTo(545, doc.y).strokeColor("#eeeeee").stroke();
        doc.moveDown(0.3);

        doc.font("Helvetica").fontSize(10);
        for (const payment of memberPayments) {
          const rowY = doc.y;
          if (rowY > 700) {
            doc.addPage();
          }
          xPos = 50;
          const rowData = [
            `R${payment.amount}`,
            MONTH_NAMES[(payment.month || 1) - 1],
            String(payment.year),
            payment.status,
            payment.method,
            payment.isCatchUp ? "Yes" : "No",
          ];
          for (let i = 0; i < rowData.length; i++) {
            doc.text(rowData[i], xPos, doc.y, { width: colWidths[i] });
            xPos += colWidths[i];
          }
          doc.moveDown(0.2);
        }

        doc.moveDown(1);
        const totalPaid = memberPayments.filter(p => p.status === "verified").reduce((sum, p) => sum + p.amount, 0);
        const totalPending = memberPayments.filter(p => p.status === "pending").reduce((sum, p) => sum + p.amount, 0);
        doc.font("Helvetica-Bold").fontSize(11);
        doc.text(`Total Verified: R${totalPaid}`);
        doc.text(`Total Pending: R${totalPending}`);
      }

      doc.end();
    } catch (error) {
      console.error("PDF generation error:", error);
      if (!res.headersSent) {
        res.status(500).json({ message: "Failed to generate PDF" });
      }
    }
  });

  app.post("/api/admin/export-sheets", isAdminAuthenticated, async (_req, res) => {
    try {
      const drive = await getGoogleDriveClient();
      const sheets = await getUncachableGoogleSheetClient();

      const now = new Date();
      const title = `Abangani_Backup_${now.toISOString().split("T")[0]}`;

      const spreadsheet = await sheets.spreadsheets.create({
        requestBody: {
          properties: { title },
          sheets: [
            { properties: { title: "Members" } },
            { properties: { title: "Payments" } },
          ],
        },
      });

      const spreadsheetId = spreadsheet.data.spreadsheetId!;

      const allMembers = await storage.getAllMembers();
      const memberRows = [
        ["ID", "Tracking #", "Full Name", "Phone", "Tier", "Monthly Amount", "Registration Month", "Registration Year", "Active", "Created"],
        ...allMembers.map(m => [
          m.id, m.trackingNumber, m.fullName, m.phone,
          TIER_PRICES[m.tier]?.name || m.tier, `R${m.monthlyAmount}`,
          String(m.registrationMonth), String(m.registrationYear),
          m.isActive ? "Yes" : "No", m.createdAt?.toISOString() || "",
        ]),
      ];

      const allPayments = await storage.getAllPayments();
      const paymentRows = [
        ["ID", "Member ID", "Amount", "Month", "Year", "Status", "Method", "Reference", "Created"],
        ...allPayments.map(p => [
          p.id, p.memberId, `R${p.amount}`,
          MONTH_NAMES[(p.month || 1) - 1], String(p.year),
          p.status, p.method, p.reference || "", p.createdAt?.toISOString() || "",
        ]),
      ];

      await sheets.spreadsheets.values.batchUpdate({
        spreadsheetId,
        requestBody: {
          valueInputOption: "RAW",
          data: [
            { range: "Members!A1", values: memberRows },
            { range: "Payments!A1", values: paymentRows },
          ],
        },
      });

      res.json({ success: true, spreadsheetId, title, url: `https://docs.google.com/spreadsheets/d/${spreadsheetId}` });
    } catch (error) {
      console.error("Google Sheets export error:", error);
      res.status(500).json({ message: "Failed to export to Google Sheets. Make sure the integration is connected." });
    }
  });

  return httpServer;
}
