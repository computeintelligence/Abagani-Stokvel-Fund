export const TIER_PRICES: Record<string, { name: string; amount: number; description: string; adminFee: number; cashbackPercent: number }> = {
  primary: {
    name: "Primary School",
    amount: 195,
    description: "School uniforms and full stationery for primary school learners",
    adminFee: 45,
    cashbackPercent: 0,
  },
  high_school: {
    name: "High School",
    amount: 295,
    description: "School uniforms and full stationery for high school learners",
    adminFee: 45,
    cashbackPercent: 0,
  },
  cashback: {
    name: "Cashback R500",
    amount: 500,
    description: "Cashback plan - withdraw 50% at the beginning of the year for school supplies",
    adminFee: 250,
    cashbackPercent: 50,
  },
  cashback_1000: {
    name: "Cashback R1000",
    amount: 1000,
    description: "Premium cashback plan - withdraw 50% at the beginning of the year for school supplies",
    adminFee: 500,
    cashbackPercent: 50,
  },
};

export const PAYMENT_START_DATE = new Date("2026-03-10T00:00:00");

export const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
