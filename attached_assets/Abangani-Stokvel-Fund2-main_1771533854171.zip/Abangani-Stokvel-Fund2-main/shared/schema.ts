import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export { users, sessions } from "@shared/models/auth";
export type { User, UpsertUser } from "@shared/models/auth";

export const subscriptionTierEnum = pgEnum("subscription_tier", ["primary", "high_school", "cashback", "cashback_1000"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "verified", "rejected", "overdue"]);
export const paymentMethodEnum = pgEnum("payment_method", ["stripe", "bank_transfer", "retailer", "card"]);
export const supplierStatusEnum = pgEnum("supplier_status", ["pending", "approved", "rejected"]);

export const members = pgTable("members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  trackingNumber: varchar("tracking_number").notNull().unique(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  address: text("address"),
  tier: subscriptionTierEnum("tier").notNull(),
  monthlyAmount: integer("monthly_amount").notNull(),
  registrationMonth: integer("registration_month").notNull(),
  registrationYear: integer("registration_year").notNull(),
  catchUpAmount: integer("catch_up_amount").notNull().default(0),
  catchUpPaid: boolean("catch_up_paid").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  agreedToTerms: boolean("agreed_to_terms").notNull().default(false),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const children = pgTable("children", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  memberId: varchar("member_id").notNull(),
  fullName: text("full_name").notNull(),
  school: text("school").notNull(),
  grade: text("grade").notNull(),
  uniformSize: text("uniform_size"),
  shoeSize: text("shoe_size"),
});

export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  memberId: varchar("member_id").notNull(),
  amount: integer("amount").notNull(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  status: paymentStatusEnum("status").notNull().default("pending"),
  method: paymentMethodEnum("method").notNull(),
  reference: text("reference"),
  proofUrl: text("proof_url"),
  isCatchUp: boolean("is_catch_up").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  verifiedAt: timestamp("verified_at"),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  memberId: varchar("member_id"),
  type: text("type").notNull(),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const suppliers = pgTable("suppliers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  contactFirstName: text("contact_first_name").notNull(),
  contactLastName: text("contact_last_name").notNull(),
  contactEmail: text("contact_email").notNull(),
  contactPhone: text("contact_phone").notNull(),
  businessName: text("business_name").notNull(),
  businessType: text("business_type").notNull(),
  businessRegistrationNumber: text("business_registration_number"),
  businessAddress: text("business_address").notNull(),
  city: text("city").notNull(),
  province: text("province").notNull(),
  productsOffered: text("products_offered").notNull(),
  agreedToLowPrices: boolean("agreed_to_low_prices").notNull().default(false),
  agreedToTerms: boolean("agreed_to_terms").notNull().default(false),
  status: supplierStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const adminSessions = pgTable("admin_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  codeHash: text("code_hash").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export type AdminSession = typeof adminSessions.$inferSelect;

export const insertMemberSchema = createInsertSchema(members).omit({
  id: true,
  createdAt: true,
  trackingNumber: true,
  catchUpAmount: true,
  catchUpPaid: true,
  isActive: true,
  stripeCustomerId: true,
  stripeSubscriptionId: true,
});

export const insertChildSchema = createInsertSchema(children).omit({
  id: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  verifiedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
  read: true,
});

export const insertSupplierSchema = createInsertSchema(suppliers).omit({
  id: true,
  createdAt: true,
  status: true,
});

export type InsertMember = z.infer<typeof insertMemberSchema>;
export type Member = typeof members.$inferSelect;
export type InsertChild = z.infer<typeof insertChildSchema>;
export type Child = typeof children.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertSupplier = z.infer<typeof insertSupplierSchema>;
export type Supplier = typeof suppliers.$inferSelect;

export { TIER_PRICES, MONTH_NAMES } from "./constants";
