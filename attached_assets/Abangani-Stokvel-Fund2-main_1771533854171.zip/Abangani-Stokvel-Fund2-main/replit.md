# Abangani NS Group - Stokvel Subscription SaaS

## Overview
A stokvel subscription platform where parents pay monthly fees to cover school uniforms and full stationery for their children at the beginning of each year. Built with React frontend and Express backend.

## Project Architecture
- **Frontend**: React + Vite + TailwindCSS + Shadcn UI (port 5000)
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL (Neon-backed via Replit)
- **Auth**: Replit Auth (OpenID Connect)
- **Payments**: Stripe integration (via stripe-replit-sync)
- **AI**: Together AI API (Qwen 2.5 72B Instruct Turbo) for notifications
- **Backup**: Google Sheets integration for monthly data exports

## Key Business Logic
- **Four tiers**: Primary School (R195/mo), High School (R295/mo), Cashback R500 (R500/mo), Cashback R1000 (R1000/mo)
- **Admin fees**: R45 for Primary/High School; Cashback members: 50% admin fee, 50% cashback withdrawal
- **Payment start date**: 10 March 2026 - payments disabled before this date (both client and server enforced)
- **Catch-up payments**: Members joining mid-year pay retroactively from January
- **Payment methods**: Card, bank/EFT transfer, retailer (Boxer/Pep/Shoprite)
- **Unique tracking numbers**: Format ABG-YEAR-XXXXXXXX

## File Structure
- `shared/schema.ts` - Drizzle ORM schema (members, children, payments, notifications)
- `shared/constants.ts` - Shared constants (TIER_PRICES, MONTH_NAMES) - safe for frontend import
- `shared/models/auth.ts` - Auth tables (sessions, users) - DO NOT modify
- `server/routes.ts` - All API endpoints
- `server/storage.ts` - Database storage layer
- `server/togetherAI.ts` - Together AI integration for notifications
- `server/googleSheetsClient.ts` - Google Sheets backup client
- `server/stripeClient.ts` - Stripe client
- `server/seed-products.ts` - Script to create Stripe products
- `client/src/pages/` - Landing, Register, Dashboard, Admin pages
- `client/src/hooks/use-auth.ts` - Auth hook (Replit Auth)

## Recent Changes
- 2026-02-18: Updated pricing and tiers
  - Added Cashback R1000 tier (4 tiers total)
  - Updated pricing: R195 Primary, R295 High School, R500/R1000 Cashback
  - Added admin fee transparency to registration agreement
  - Added payment start date enforcement (10 March 2026)
- 2026-02-16: Initial build - complete platform with all features
  - Database schema, storage layer, API routes
  - Landing page, registration wizard, user dashboard, admin panel
  - Together AI notifications, Google Sheets backup
  - Dark/light theme support

## User Preferences
- Uses Together AI API (not OpenAI) - user provides TOGETHER_API_KEY secret
- Currency: South African Rand (R)
- South African English
