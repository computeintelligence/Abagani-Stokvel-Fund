import { Link } from "wouter";
import { Shield } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t bg-muted/30 mt-auto">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Shield className="h-5 w-5 text-primary" />
              <span className="font-bold">Abangani NS Group</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Stokvel savings for school uniforms and stationery. Together we build brighter futures.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-sm mb-3">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-sm text-muted-foreground hover:text-foreground">Home</Link></li>
              <li><Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">About Us</Link></li>
              <li><Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">Contact</Link></li>
              <li><Link href="/auth" className="text-sm text-muted-foreground hover:text-foreground">Sign In / Sign Up</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-sm mb-3">For Members</h3>
            <ul className="space-y-2">
              <li><Link href="/register" className="text-sm text-muted-foreground hover:text-foreground">Register</Link></li>
              <li><Link href="/dashboard" className="text-sm text-muted-foreground hover:text-foreground">Dashboard</Link></li>
              <li><Link href="/profile" className="text-sm text-muted-foreground hover:text-foreground">My Profile</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-sm mb-3">Partners</h3>
            <ul className="space-y-2">
              <li><Link href="/supplier-register" className="text-sm text-muted-foreground hover:text-foreground" data-testid="link-supplier-register">Register as Supplier</Link></li>
              <li><span className="text-sm text-muted-foreground">info@abanganins.co.za</span></li>
              <li><span className="text-sm text-muted-foreground">071 234 5678</span></li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-6 text-center text-xs text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Abangani NS Group. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
