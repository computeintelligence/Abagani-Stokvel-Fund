import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { Shield, Menu, X, User } from "lucide-react";

export default function Navbar() {
  const { user, isLoading, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const member = (user as any)?.member;

  const navLinks = [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 px-4 py-3">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <Shield className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg" data-testid="text-brand-nav">Abangani NS Group</span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map(link => (
            <Button key={link.href} variant="ghost" size="sm" asChild>
              <Link href={link.href} data-testid={`nav-link-${link.label.toLowerCase()}`}>{link.label}</Link>
            </Button>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-2">
          <ThemeToggle />
          {isLoading ? null : isAuthenticated ? (
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => navigate(member ? "/dashboard" : "/register")} data-testid="nav-button-dashboard">
                {member ? "Dashboard" : "Register"}
              </Button>
              <Button variant="ghost" size="icon" onClick={() => navigate("/profile")} data-testid="nav-button-profile">
                <User className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => navigate("/auth")} data-testid="nav-button-login">
                Sign In
              </Button>
              <Button size="sm" onClick={() => navigate("/auth")} data-testid="nav-button-signup">
                Sign Up
              </Button>
            </div>
          )}
        </div>

        <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)} data-testid="button-mobile-menu">
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t bg-background px-4 py-3 space-y-2">
          {navLinks.map(link => (
            <Button key={link.href} variant="ghost" className="w-full justify-start" asChild onClick={() => setMobileOpen(false)}>
              <Link href={link.href}>{link.label}</Link>
            </Button>
          ))}
          <div className="border-t pt-2 space-y-2">
            {isAuthenticated ? (
              <>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { setMobileOpen(false); navigate(member ? "/dashboard" : "/register"); }}>
                  {member ? "Dashboard" : "Register"}
                </Button>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { setMobileOpen(false); navigate("/profile"); }}>
                  Profile
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { setMobileOpen(false); navigate("/auth"); }}>
                  Sign In
                </Button>
                <Button className="w-full" onClick={() => { setMobileOpen(false); navigate("/auth"); }}>
                  Sign Up
                </Button>
              </>
            )}
            <div className="flex justify-start pt-1">
              <ThemeToggle />
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
