import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TIER_PRICES } from "@shared/constants";
import { ArrowLeft, ArrowRight, GraduationCap, BookOpen, Gift, Coins, Plus, X, CheckCircle, Loader2 } from "lucide-react";
import { FadeUp, ScaleIn, StaggerContainer, StaggerItem, motion } from "@/components/motion";
import { AnimatePresence } from "framer-motion";
import { isUnauthorizedError, redirectToLogin } from "@/lib/auth-utils";

const STEPS = ["Plan", "Parent Info", "Children", "Summary", "Agreement"];
const tierIcons: Record<string, any> = { primary: GraduationCap, high_school: BookOpen, cashback: Gift, cashback_1000: Coins };

interface ChildData { fullName: string; school: string; grade: string; uniformSize: string; shoeSize: string; }

export default function Register() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(0);
  const [selectedTier, setSelectedTier] = useState("");
  const [parent, setParent] = useState({ fullName: "", phone: "", address: "" });
  const [childrenData, setChildrenData] = useState<ChildData[]>([{ fullName: "", school: "", grade: "", uniformSize: "", shoeSize: "" }]);
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const now = new Date();
  const registrationMonth = now.getMonth() + 1;
  const tierInfo = TIER_PRICES[selectedTier];
  const catchUpMonths = registrationMonth - 1;
  const catchUpAmount = catchUpMonths * (tierInfo?.amount || 0);
  const totalFirstPayment = catchUpAmount + (tierInfo?.amount || 0);

  const registerMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/register", {
        parent,
        children: childrenData,
        tier: selectedTier,
        agreedToTerms,
      });
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({ title: "Registration Successful!", description: `Your tracking number is ${data.member.trackingNumber}` });
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        redirectToLogin(toast as any);
        return;
      }
      toast({ title: "Registration Failed", description: error.message, variant: "destructive" });
    },
  });

  if (isLoading) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (!isAuthenticated) { window.location.href = "/api/login"; return null; }
  if ((user as any)?.member) { navigate("/dashboard"); return null; }

  const canNext = () => {
    if (step === 0) return !!selectedTier;
    if (step === 1) return parent.fullName.trim() && parent.phone.trim();
    if (step === 2) return childrenData.every(c => c.fullName.trim() && c.school.trim() && c.grade.trim());
    if (step === 3) return true;
    if (step === 4) return agreedToTerms;
    return false;
  };

  const addChild = () => setChildrenData([...childrenData, { fullName: "", school: "", grade: "", uniformSize: "", shoeSize: "" }]);
  const removeChild = (i: number) => { if (childrenData.length > 1) setChildrenData(childrenData.filter((_, idx) => idx !== i)); };
  const updateChild = (i: number, field: keyof ChildData, value: string) => {
    const updated = [...childrenData];
    updated[i] = { ...updated[i], [field]: value };
    setChildrenData(updated);
  };

  const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto">
        <Button variant="ghost" onClick={() => step > 0 ? setStep(step - 1) : navigate("/")} className="mb-4" data-testid="button-back">
          <ArrowLeft className="h-4 w-4 mr-2" /> {step > 0 ? "Back" : "Home"}
        </Button>

        <div className="mb-6">
          <div className="flex items-center gap-2 flex-wrap mb-2">
            {STEPS.map((s, i) => (
              <Badge key={s} variant={i === step ? "default" : i < step ? "secondary" : "outline"} data-testid={`badge-step-${i}`}>
                {i < step ? <CheckCircle className="h-3 w-3 mr-1" /> : null} {s}
              </Badge>
            ))}
          </div>
          <Progress value={((step + 1) / STEPS.length) * 100} className="h-2" />
        </div>

        <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="step-0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}>
            <h2 className="text-xl font-bold mb-4">Choose Your Plan</h2>
            <StaggerContainer className="grid gap-4" staggerDelay={0.08}>
              {Object.entries(TIER_PRICES).map(([key, tier]) => {
                const Icon = tierIcons[key] || Gift;
                return (
                  <StaggerItem key={key}>
                    <Card
                      className={`cursor-pointer hover-elevate ${selectedTier === key ? "border-primary" : ""}`}
                      onClick={() => setSelectedTier(key)}
                      data-testid={`card-tier-${key}`}
                    >
                      <CardContent className="flex items-center gap-4 p-4">
                        <Icon className="h-8 w-8 text-primary shrink-0" />
                        <div className="flex-1">
                          <div className="font-semibold">{tier.name}</div>
                          <div className="text-sm text-muted-foreground">{tier.description}</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {tier.cashbackPercent > 0
                              ? `R${tier.adminFee} admin fee | ${tier.cashbackPercent}% cashback (R${tier.amount - tier.adminFee}) at year start`
                              : `Includes R${tier.adminFee} administration fee`}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-xl font-bold">R{tier.amount}</div>
                          <div className="text-xs text-muted-foreground">/month</div>
                        </div>
                        {selectedTier === key && <CheckCircle className="h-5 w-5 text-primary shrink-0" />}
                      </CardContent>
                    </Card>
                  </StaggerItem>
                );
              })}
            </StaggerContainer>
          </motion.div>
        )}

        {step === 1 && (
          <motion.div key="step-1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}>
            <h2 className="text-xl font-bold mb-4">Parent / Guardian Information</h2>
            <Card>
              <CardContent className="p-4 space-y-4">
                <div>
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input id="fullName" value={parent.fullName} onChange={e => setParent({ ...parent, fullName: e.target.value })} placeholder="Enter your full name" data-testid="input-parent-name" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" value={parent.phone} onChange={e => setParent({ ...parent, phone: e.target.value })} placeholder="e.g. 071 234 5678" data-testid="input-parent-phone" />
                </div>
                <div>
                  <Label htmlFor="address">Address (optional)</Label>
                  <Input id="address" value={parent.address} onChange={e => setParent({ ...parent, address: e.target.value })} placeholder="Enter your address" data-testid="input-parent-address" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div key="step-2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}>
            <h2 className="text-xl font-bold mb-4">Children Details</h2>
            <div className="space-y-4">
              {childrenData.map((child, i) => (
                <Card key={i}>
                  <CardHeader className="flex flex-row items-center justify-between gap-2 p-4 pb-2">
                    <CardTitle className="text-base">Child {i + 1}</CardTitle>
                    {childrenData.length > 1 && (
                      <Button size="icon" variant="ghost" onClick={() => removeChild(i)} data-testid={`button-remove-child-${i}`}>
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </CardHeader>
                  <CardContent className="p-4 pt-0 space-y-3">
                    <div>
                      <Label>Full Name</Label>
                      <Input value={child.fullName} onChange={e => updateChild(i, "fullName", e.target.value)} placeholder="Child's full name" data-testid={`input-child-name-${i}`} />
                    </div>
                    <div>
                      <Label>School</Label>
                      <Input value={child.school} onChange={e => updateChild(i, "school", e.target.value)} placeholder="School name" data-testid={`input-child-school-${i}`} />
                    </div>
                    <div>
                      <Label>Grade</Label>
                      <Select value={child.grade} onValueChange={v => updateChild(i, "grade", v)}>
                        <SelectTrigger data-testid={`select-child-grade-${i}`}>
                          <SelectValue placeholder="Select grade" />
                        </SelectTrigger>
                        <SelectContent>
                          {["Grade R", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"].map(g => (
                            <SelectItem key={g} value={g}>{g}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label>Uniform Size (optional)</Label>
                        <Input value={child.uniformSize} onChange={e => updateChild(i, "uniformSize", e.target.value)} placeholder="e.g. 28" data-testid={`input-child-uniform-${i}`} />
                      </div>
                      <div>
                        <Label>Shoe Size (optional)</Label>
                        <Input value={child.shoeSize} onChange={e => updateChild(i, "shoeSize", e.target.value)} placeholder="e.g. 5" data-testid={`input-child-shoe-${i}`} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              <Button variant="outline" onClick={addChild} className="w-full" data-testid="button-add-child">
                <Plus className="h-4 w-4 mr-2" /> Add Another Child
              </Button>
            </div>
          </motion.div>
        )}

        {step === 3 && tierInfo && (
          <motion.div key="step-3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}>
            <h2 className="text-xl font-bold mb-4">Registration Summary</h2>
            <Card>
              <CardContent className="p-4 space-y-4">
                <div>
                  <h3 className="font-semibold mb-1">Plan</h3>
                  <p className="text-muted-foreground">{tierInfo.name} - R{tierInfo.amount}/month</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Parent / Guardian</h3>
                  <p className="text-muted-foreground">{parent.fullName} | {parent.phone}</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Children ({childrenData.length})</h3>
                  {childrenData.map((c, i) => (
                    <p key={i} className="text-muted-foreground">{c.fullName} - {c.school} ({c.grade})</p>
                  ))}
                </div>

                {catchUpMonths > 0 && (
                  <Card className="bg-accent/10 border-accent/30">
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2">Catch-Up Payment Required</h3>
                      <p className="text-sm text-muted-foreground mb-2">
                        Since you're joining in {MONTH_NAMES[registrationMonth - 1]}, you need to cover the months from January to {MONTH_NAMES[registrationMonth - 2]}.
                      </p>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between"><span>Catch-up ({catchUpMonths} months x R{tierInfo.amount})</span><span className="font-medium">R{catchUpAmount}</span></div>
                        <div className="flex justify-between"><span>{MONTH_NAMES[registrationMonth - 1]} payment</span><span className="font-medium">R{tierInfo.amount}</span></div>
                        <div className="flex justify-between border-t pt-1 font-bold"><span>Total first payment</span><span>R{totalFirstPayment}</span></div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div>
                  <h3 className="font-semibold mb-1">Monthly Payment Going Forward</h3>
                  <p className="text-2xl font-bold text-primary">R{tierInfo.amount}/month</p>
                  <p className="text-sm text-muted-foreground">From {MONTH_NAMES[registrationMonth - 1]} to December {now.getFullYear()}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {step === 4 && (
          <motion.div key="step-4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}>
            <h2 className="text-xl font-bold mb-4">Terms & Agreement</h2>
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="prose prose-sm dark:prose-invert max-h-72 overflow-y-auto">
                  <h4>Abangani NS Group Membership Agreement</h4>
                  <p>By joining Abangani NS Group, I agree to the following:</p>
                  <ul>
                    <li>I commit to paying my monthly subscription of <strong>R{tierInfo?.amount}</strong> on time each month.</li>
                    {tierInfo && tierInfo.cashbackPercent === 0 && (
                      <li>Of my monthly R{tierInfo.amount} subscription, <strong>R{tierInfo.adminFee}</strong> goes towards administration fees. The remaining <strong>R{tierInfo.amount - tierInfo.adminFee}</strong> goes directly towards school uniforms and stationery for my child(ren).</li>
                    )}
                    {tierInfo && tierInfo.cashbackPercent > 0 && (
                      <li>Of my monthly R{tierInfo.amount} subscription, <strong>50% (R{tierInfo.adminFee})</strong> goes towards administration fees, and the other <strong>50% (R{tierInfo.amount - tierInfo.adminFee})</strong> is available as cashback. I may withdraw my cashback portion at the beginning of the year when it is time to purchase school uniforms and stationery.</li>
                    )}
                    <li>If I join mid-year, I understand that I must pay the catch-up amount from January to my registration month.</li>
                    <li>Benefits (school uniforms, stationery, or cashback) are distributed at the beginning of each calendar year, provided all payments are up to date.</li>
                    <li>If my payments fall behind by more than 2 months, my membership may be reviewed by the group administrators.</li>
                    <li>Payment methods will be available from the <strong>10th of March 2026</strong>.</li>
                    <li>I can pay via online card payment, bank/EFT transfer, or at participating retailers (Boxer, Pep, Shoprite).</li>
                    <li>All payments must be verified with proof of payment for manual payments (bank transfer or retailer).</li>
                    <li>My personal and children's information will be kept confidential and used only for group administration purposes.</li>
                  </ul>
                </div>
                <div className="flex items-start gap-2 pt-4 border-t">
                  <Checkbox
                    id="agree"
                    checked={agreedToTerms}
                    onCheckedChange={(checked) => setAgreedToTerms(checked === true)}
                    data-testid="checkbox-agree"
                  />
                  <Label htmlFor="agree" className="text-sm leading-tight cursor-pointer">
                    I have read and agree to the Abangani NS Group membership terms and conditions
                  </Label>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
        </AnimatePresence>

        <div className="flex justify-between gap-4 mt-6">
          <Button variant="outline" onClick={() => step > 0 ? setStep(step - 1) : navigate("/")} data-testid="button-prev">
            <ArrowLeft className="h-4 w-4 mr-2" /> {step > 0 ? "Previous" : "Cancel"}
          </Button>
          {step < STEPS.length - 1 ? (
            <Button onClick={() => setStep(step + 1)} disabled={!canNext()} data-testid="button-next">
              Next <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={() => registerMutation.mutate()} disabled={!canNext() || registerMutation.isPending} data-testid="button-submit">
              {registerMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
              Complete Registration
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
