import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { TIER_PRICES } from "@shared/constants";
import {
  Shield, LogOut, Copy, Loader2, Mail, Phone, MapPin,
  Users, GraduationCap, ArrowLeft
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { FadeUp, ScaleIn, StaggerContainer, StaggerItem, motion } from "@/components/motion";
import Navbar from "@/components/navbar";

export default function Profile() {
  const { user, isLoading: authLoading, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const member = (user as any)?.member;

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/member/profile"],
    enabled: !!member,
  });

  if (authLoading) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (!isAuthenticated) { navigate("/auth"); return null; }

  const tierInfo = member ? TIER_PRICES[member.tier] : null;
  const p = profile as any;
  const initials = `${(user as any)?.firstName?.charAt(0) || ""}${(user as any)?.lastName?.charAt(0) || ""}`.toUpperCase() || "U";

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <div className="max-w-3xl mx-auto w-full p-4 space-y-6 flex-1">
        <FadeUp>
          <Button variant="ghost" onClick={() => navigate("/dashboard")} data-testid="button-back-dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Dashboard
          </Button>
        </FadeUp>

        <ScaleIn delay={0.1}>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4 flex-wrap">
              <Avatar className="h-16 w-16">
                <AvatarFallback className="text-xl bg-primary/10 text-primary">{initials}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <h1 className="text-xl font-bold" data-testid="text-profile-name">
                  {(user as any)?.firstName} {(user as any)?.lastName}
                </h1>
                <div className="flex items-center gap-2 flex-wrap mt-1">
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Mail className="h-3.5 w-3.5" /> {(user as any)?.email}
                  </div>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => { logout(); navigate("/"); }} data-testid="button-logout-profile">
                <LogOut className="h-4 w-4 mr-1" /> Sign Out
              </Button>
            </div>
          </CardContent>
        </Card>
        </ScaleIn>

        {member ? (
          <>
            <FadeUp delay={0.2}><Card>
              <CardHeader>
                <CardTitle className="text-base">Membership Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-sm text-muted-foreground">Tracking Number</span>
                  <Badge
                    variant="outline"
                    className="cursor-pointer"
                    onClick={() => { navigator.clipboard.writeText(member.trackingNumber); toast({ title: "Copied!", description: "Tracking number copied" }); }}
                    data-testid="badge-tracking-profile"
                  >
                    {member.trackingNumber} <Copy className="h-3 w-3 ml-1" />
                  </Badge>
                </div>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-sm text-muted-foreground">Plan</span>
                  <Badge variant="secondary" data-testid="badge-tier-profile">{tierInfo?.name}</Badge>
                </div>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-sm text-muted-foreground">Monthly Amount</span>
                  <span className="font-semibold text-sm">R{member.monthlyAmount}</span>
                </div>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-sm text-muted-foreground">Phone</span>
                  <span className="text-sm">{member.phone}</span>
                </div>
                {member.address && (
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-sm text-muted-foreground">Address</span>
                    <span className="text-sm">{member.address}</span>
                  </div>
                )}
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <Badge variant={member.isActive ? "default" : "destructive"}>{member.isActive ? "Active" : "Inactive"}</Badge>
                </div>
              </CardContent>
            </Card></FadeUp>

            {p?.children?.length > 0 && (
              <FadeUp delay={0.3}><Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <GraduationCap className="h-4 w-4" /> Children ({p.children.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {p.children.map((child: any) => (
                      <div key={child.id} className="flex items-center gap-3 p-3 rounded-md bg-muted/30">
                        <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-bold shrink-0">
                          {child.fullName.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm">{child.fullName}</div>
                          <div className="text-xs text-muted-foreground">{child.school} - {child.grade}</div>
                          <div className="text-xs text-muted-foreground">
                            {child.uniformSize && `Uniform: ${child.uniformSize}`}
                            {child.uniformSize && child.shoeSize && " | "}
                            {child.shoeSize && `Shoes: ${child.shoeSize}`}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card></FadeUp>
            )}
          </>
        ) : (
          <ScaleIn delay={0.2}><Card>
            <CardContent className="p-8 text-center">
              <Users className="h-10 w-10 mx-auto mb-4 text-muted-foreground" />
              <h3 className="font-semibold mb-2">Not Yet Registered</h3>
              <p className="text-sm text-muted-foreground mb-4">
                You haven't completed your stokvel membership registration yet.
              </p>
              <Button onClick={() => navigate("/register")} data-testid="button-register-profile">
                Complete Registration
              </Button>
            </CardContent>
          </Card></ScaleIn>
        )}
      </div>
    </div>
  );
}
