import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Mail, Phone, MapPin, Clock, Send, Loader2 } from "lucide-react";
import { FadeUp, ScaleIn, StaggerContainer, StaggerItem } from "@/components/motion";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

export default function Contact() {
  const { toast } = useToast();
  const [sending, setSending] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast({ title: "Missing Fields", description: "Please fill in all required fields.", variant: "destructive" });
      return;
    }
    setSending(true);
    await new Promise(r => setTimeout(r, 1000));
    setSending(false);
    toast({ title: "Message Sent", description: "Thank you for reaching out. We will get back to you shortly." });
    setForm({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <section className="py-16 px-4">
        <FadeUp>
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-contact-title">Contact Us</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Have questions about joining our stokvel or need help with your account? We are here to help.
            </p>
          </div>
        </FadeUp>
      </section>

      <section className="pb-16 px-4">
        <div className="max-w-5xl mx-auto grid md:grid-cols-3 gap-6">
          <FadeUp delay={0.1} className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Send Us a Message</CardTitle>
                <CardDescription>We will respond within 24 hours</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input id="name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your name" data-testid="input-contact-name" />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input id="email" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" data-testid="input-contact-email" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="subject">Subject</Label>
                    <Input id="subject" value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} placeholder="What is this about?" data-testid="input-contact-subject" />
                  </div>
                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea id="message" value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} placeholder="Tell us how we can help..." rows={5} data-testid="input-contact-message" />
                  </div>
                  <Button type="submit" disabled={sending} data-testid="button-send-message">
                    {sending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </FadeUp>

          <StaggerContainer className="space-y-4" staggerDelay={0.1}>
            <StaggerItem><Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <Mail className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h3 className="font-semibold text-sm mb-1">Email</h3>
                    <p className="text-sm text-muted-foreground">info@abanganins.co.za</p>
                  </div>
                </div>
              </CardContent>
            </Card></StaggerItem>
            <StaggerItem><Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <Phone className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h3 className="font-semibold text-sm mb-1">Phone</h3>
                    <p className="text-sm text-muted-foreground">071 234 5678</p>
                  </div>
                </div>
              </CardContent>
            </Card></StaggerItem>
            <StaggerItem><Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h3 className="font-semibold text-sm mb-1">Location</h3>
                    <p className="text-sm text-muted-foreground">Gauteng, South Africa</p>
                  </div>
                </div>
              </CardContent>
            </Card></StaggerItem>
            <StaggerItem><Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h3 className="font-semibold text-sm mb-1">Office Hours</h3>
                    <p className="text-sm text-muted-foreground">Mon - Fri: 8am - 5pm</p>
                    <p className="text-sm text-muted-foreground">Sat: 9am - 1pm</p>
                  </div>
                </div>
              </CardContent>
            </Card></StaggerItem>
          </StaggerContainer>
        </div>
      </section>

      <Footer />
    </div>
  );
}
