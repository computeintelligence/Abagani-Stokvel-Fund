import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { TIER_PRICES, PAYMENT_START_DATE } from "@shared/constants";
import {
  Shield, LogOut, Bell, CreditCard, Users, CheckCircle, Clock, AlertCircle,
  Copy, Loader2, CalendarDays, User, Upload
} from "lucide-react";
import { useState, useRef } from "react";
import { FadeUp, ScaleIn, StaggerContainer, StaggerItem, motion } from "@/components/motion";
import Navbar from "@/components/navbar";

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

export default function Dashboard() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [paymentMonth, setPaymentMonth] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("bank_transfer");
  const [paymentRef, setPaymentRef] = useState("");
  const [showPayDialog, setShowPayDialog] = useState(false);
  const [proofUrl, setProofUrl] = useState("");
  const [uploadStatus, setUploadStatus] = useState<"idle" | "uploading" | "done" | "error">("idle");
  const [uploadFileName, setUploadFileName] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const member = (user as any)?.member;

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/member/profile"],
    enabled: !!member,
  });

  const { data: paymentStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/member/payment-status"],
    enabled: !!member,
  });

  const { data: notifs } = useQuery({
    queryKey: ["/api/notifications"],
    enabled: !!member,
  });

  const payMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/payments", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/member/payment-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/member/profile"] });
      toast({ title: "Payment Submitted", description: "Your payment has been recorded and is pending verification." });
      setShowPayDialog(false);
      setPaymentRef("");
      setPaymentMonth("");
      setProofUrl("");
      setUploadStatus("idle");
      setUploadFileName("");
    },
    onError: (error: Error) => {
      toast({ title: "Payment Failed", description: error.message, variant: "destructive" });
    },
  });

  const markReadMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("POST", `/api/notifications/${id}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  if (authLoading) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (!isAuthenticated) { navigate("/auth"); return null; }
  if (!member) { navigate("/register"); return null; }

  const tierInfo = TIER_PRICES[member.tier];
  const paymentsEnabled = new Date() >= PAYMENT_START_DATE;
  const ps = paymentStatus as any;
  const unreadNotifs = (notifs as any[])?.filter((n: any) => !n.read) || [];

  const handleFileUpload = async (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File too large", description: "Maximum file size is 5MB", variant: "destructive" });
      return;
    }
    setUploadStatus("uploading");
    setUploadFileName(file.name);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload/proof", { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) throw new Error("Upload failed");
      const data = await res.json();
      setProofUrl(data.url);
      setUploadStatus("done");
      toast({ title: "Upload Complete", description: "Proof of payment uploaded successfully." });
    } catch {
      setUploadStatus("error");
      toast({ title: "Upload Failed", description: "Could not upload file. Please try again.", variant: "destructive" });
    }
  };

  const handleSubmitPayment = () => {
    if (!paymentMonth) return;
    const [yearStr, monthStr] = paymentMonth.split("-");
    payMutation.mutate({
      amount: member.monthlyAmount,
      month: parseInt(monthStr),
      year: parseInt(yearStr),
      method: paymentMethod,
      reference: paymentRef || null,
      proofUrl: proofUrl || null,
      isCatchUp: false,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 flex items-center justify-between gap-4 flex-wrap p-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          <span className="font-bold" data-testid="text-brand">Abangani NS Group</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="relative" onClick={() => {}} data-testid="button-notifications">
            <Bell className="h-4 w-4" />
            {unreadNotifs.length > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 text-[10px] rounded-full bg-destructive text-destructive-foreground flex items-center justify-center">{unreadNotifs.length}</span>
            )}
          </Button>
          <Button variant="ghost" size="icon" onClick={() => navigate("/profile")} data-testid="button-profile">
            <User className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        <FadeUp>
          <div>
            <h1 className="text-2xl font-bold" data-testid="text-welcome">Welcome, {member.fullName}</h1>
            <div className="flex items-center gap-2 flex-wrap mt-1">
              <Badge variant="secondary" data-testid="badge-tier">{tierInfo?.name}</Badge>
              <Badge variant="outline" data-testid="badge-tracking" className="cursor-pointer" onClick={() => { navigator.clipboard.writeText(member.trackingNumber); toast({ title: "Copied!", description: "Tracking number copied to clipboard" }); }}>
                {member.trackingNumber} <Copy className="h-3 w-3 ml-1" />
              </Badge>
            </div>
          </div>
        </FadeUp>

        {ps && (
          <ScaleIn delay={0.15}><Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Payment Progress {new Date().getFullYear()}</CardTitle>
              <CardDescription>R{ps.totalPaid?.toLocaleString()} of R{ps.totalDue?.toLocaleString()} paid</CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={ps.progress || 0} className="h-3 mb-4" />
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="text-center">
                  <div className="text-xl font-bold text-primary">R{member.monthlyAmount}</div>
                  <div className="text-xs text-muted-foreground">Monthly</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold">{ps.months?.filter((m: any) => m.status === "paid").length || 0}</div>
                  <div className="text-xs text-muted-foreground">Months Paid</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-destructive">{ps.months?.filter((m: any) => m.status === "unpaid").length || 0}</div>
                  <div className="text-xs text-muted-foreground">Unpaid</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold">{ps.progress || 0}%</div>
                  <div className="text-xs text-muted-foreground">Complete</div>
                </div>
              </div>
            </CardContent>
          </Card></ScaleIn>
        )}

        <StaggerContainer className="grid md:grid-cols-2 gap-4" staggerDelay={0.1}>
          <StaggerItem><Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="text-base">Monthly Payments</CardTitle>
                <Dialog open={showPayDialog} onOpenChange={setShowPayDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm" disabled={!paymentsEnabled} data-testid="button-make-payment">
                      <CreditCard className="h-4 w-4 mr-1" /> Pay
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Submit Payment</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label>Month</Label>
                        <Select value={paymentMonth} onValueChange={setPaymentMonth}>
                          <SelectTrigger data-testid="select-payment-month">
                            <SelectValue placeholder="Select month" />
                          </SelectTrigger>
                          <SelectContent>
                            {ps?.months?.filter((m: any) => m.status === "unpaid").map((m: any) => (
                              <SelectItem key={`${m.year}-${m.month}`} value={`${m.year}-${m.month}`}>
                                {m.name} {m.year}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Payment Method</Label>
                        <Select value={paymentMethod} onValueChange={(v) => { setPaymentMethod(v); setPaymentRef(""); setProofUrl(""); setUploadStatus("idle"); setUploadFileName(""); }}>
                          <SelectTrigger data-testid="select-payment-method">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="card">Card Payment (Online)</SelectItem>
                            <SelectItem value="bank_transfer">Bank/EFT Transfer</SelectItem>
                            <SelectItem value="retailer">Retailer (Boxer/Pep/Shoprite)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {paymentMethod === "bank_transfer" && (
                        <>
                          <div className="rounded-md border p-3 space-y-1 text-sm" data-testid="bank-details">
                            <div className="font-medium text-foreground">Bank Details</div>
                            <div className="text-muted-foreground">Bank: <span className="text-foreground">Capitec</span></div>
                            <div className="text-muted-foreground">Account: <span className="text-foreground">1234567890</span></div>
                            <div className="text-muted-foreground">Reference: <span className="text-foreground">{member.trackingNumber}</span></div>
                          </div>
                          <div>
                            <Label>Proof of Payment</Label>
                            <input
                              ref={fileInputRef}
                              type="file"
                              accept="image/*,.pdf"
                              className="hidden"
                              data-testid="input-proof-upload"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleFileUpload(file);
                              }}
                            />
                            <div
                              className="mt-1 flex flex-col items-center justify-center gap-2 rounded-md border border-dashed p-4 cursor-pointer text-muted-foreground"
                              onClick={() => fileInputRef.current?.click()}
                              data-testid="button-upload-proof"
                            >
                              {uploadStatus === "uploading" && (
                                <>
                                  <Loader2 className="h-6 w-6 animate-spin" />
                                  <span className="text-sm">Uploading {uploadFileName}...</span>
                                </>
                              )}
                              {uploadStatus === "done" && (
                                <>
                                  <CheckCircle className="h-6 w-6 text-green-500" />
                                  <span className="text-sm text-foreground">{uploadFileName}</span>
                                  <span className="text-xs">Click to replace</span>
                                </>
                              )}
                              {uploadStatus === "error" && (
                                <>
                                  <AlertCircle className="h-6 w-6 text-destructive" />
                                  <span className="text-sm text-destructive">Upload failed - click to retry</span>
                                </>
                              )}
                              {uploadStatus === "idle" && (
                                <>
                                  <Upload className="h-6 w-6" />
                                  <span className="text-sm">Click to upload proof (image or PDF, max 5MB)</span>
                                </>
                              )}
                            </div>
                          </div>
                        </>
                      )}

                      {paymentMethod === "retailer" && (
                        <div>
                          <Label>Reference Number</Label>
                          <Input value={paymentRef} onChange={e => setPaymentRef(e.target.value)} placeholder="Enter retailer reference number" data-testid="input-payment-ref" />
                        </div>
                      )}

                      <div className="text-sm text-muted-foreground">
                        Amount: <span className="font-bold text-foreground">R{member.monthlyAmount}</span>
                      </div>
                      <Button onClick={handleSubmitPayment} disabled={!paymentMonth || payMutation.isPending} className="w-full" data-testid="button-confirm-payment">
                        {payMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                        Submit Payment
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              {!paymentsEnabled && (
                <div className="mb-3 p-3 rounded-md bg-muted text-sm text-muted-foreground" data-testid="text-payments-notice">
                  Payments will be available from <strong>10 March 2026</strong>. You can register now and start paying from that date.
                </div>
              )}
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {ps?.months?.map((m: any) => (
                  <div key={`${m.year}-${m.month}`} className="flex items-center justify-between gap-2 text-sm py-1">
                    <div className="flex items-center gap-2">
                      <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
                      <span>{m.name} {m.year}</span>
                    </div>
                    {m.status === "paid" && <Badge variant="default" className="text-xs"><CheckCircle className="h-3 w-3 mr-1" />Paid</Badge>}
                    {m.status === "pending" && <Badge variant="secondary" className="text-xs"><Clock className="h-3 w-3 mr-1" />Pending</Badge>}
                    {m.status === "unpaid" && <Badge variant="destructive" className="text-xs"><AlertCircle className="h-3 w-3 mr-1" />Unpaid</Badge>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card></StaggerItem>

          <StaggerItem><Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Children</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {(profile as any)?.children?.map((child: any) => (
                  <motion.div key={child.id} className="flex items-center gap-3" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.3 }}>
                    <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-bold shrink-0">
                      {child.fullName.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{child.fullName}</div>
                      <div className="text-xs text-muted-foreground truncate">{child.school} - {child.grade}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card></StaggerItem>
        </StaggerContainer>

        {unreadNotifs.length > 0 && (
          <FadeUp delay={0.3}>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Bell className="h-4 w-4" /> Notifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {unreadNotifs.map((n: any, i: number) => (
                    <motion.div key={n.id} className="flex items-start gap-3 p-3 rounded-md bg-muted/50" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05, duration: 0.3 }}>
                      <div className="flex-1 text-sm">{n.message}</div>
                      <Button size="sm" variant="ghost" onClick={() => markReadMutation.mutate(n.id)} data-testid={`button-dismiss-${n.id}`}>
                        Dismiss
                      </Button>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </FadeUp>
        )}

        {(profile as any)?.payments?.length > 0 && (
          <FadeUp delay={0.4}>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Transaction History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {(profile as any)?.payments?.slice(0, 10).map((p: any, i: number) => (
                    <motion.div key={p.id} className="flex items-center justify-between gap-2 text-sm py-1 border-b last:border-0" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04, duration: 0.3 }}>
                      <div>
                        <span>{MONTH_NAMES[(p.month || 1) - 1]} {p.year}</span>
                        <span className="text-muted-foreground ml-2">via {p.method?.replace("_", " ")}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">R{p.amount}</span>
                        {p.status === "verified" && <Badge variant="default" className="text-xs">Verified</Badge>}
                        {p.status === "pending" && <Badge variant="secondary" className="text-xs">Pending</Badge>}
                        {p.status === "rejected" && <Badge variant="destructive" className="text-xs">Rejected</Badge>}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </FadeUp>
        )}
      </div>
    </div>
  );
}
