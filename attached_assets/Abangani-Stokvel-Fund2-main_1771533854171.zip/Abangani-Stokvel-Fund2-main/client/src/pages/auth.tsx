import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, Loader2, Eye, EyeOff } from "lucide-react";
import { FadeUp, ScaleIn, motion } from "@/components/motion";

export default function AuthPage() {
  const { login, signup, isLoggingIn, isSigningUp, isAuthenticated, user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    email: "",
    password: "",
    firstName: "",
    lastName: "",
  });

  useEffect(() => {
    if (isAuthenticated) {
      if ((user as any)?.member) {
        navigate("/dashboard");
      } else {
        navigate("/register");
      }
    }
  }, [isAuthenticated, user, navigate]);

  if (isAuthenticated) {
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isLogin) {
        await login({ email: form.email, password: form.password });
        toast({ title: "Welcome back!", description: "You have been signed in successfully." });
      } else {
        if (!form.firstName.trim() || !form.lastName.trim()) {
          toast({ title: "Missing Information", description: "Please fill in your first and last name.", variant: "destructive" });
          return;
        }
        if (form.password.length < 6) {
          toast({ title: "Password Too Short", description: "Password must be at least 6 characters.", variant: "destructive" });
          return;
        }
        await signup(form);
        toast({ title: "Account Created!", description: "Welcome to Abangani NS Group. Check your email for a welcome message." });
      }
      navigate("/");
    } catch (error: any) {
      const msg = error?.message?.includes(":") ? error.message.split(": ").slice(1).join(": ") : error?.message || "Something went wrong";
      toast({ title: isLogin ? "Login Failed" : "Signup Failed", description: msg, variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <FadeUp delay={0.1}>
          <div className="text-center mb-8">
            <motion.div
              className="flex items-center justify-center gap-2 mb-3"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, type: "spring", stiffness: 200 }}
            >
              <Shield className="h-8 w-8 text-primary" />
              <span className="font-bold text-2xl">Abangani NS Group</span>
            </motion.div>
            <p className="text-muted-foreground text-sm">Stokvel Savings for School Uniforms & Stationery</p>
          </div>
        </FadeUp>

        <ScaleIn delay={0.2}>
          <Card>
            <CardHeader className="text-center pb-4">
              <motion.div
                key={isLogin ? "login" : "signup"}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <CardTitle className="text-xl">{isLogin ? "Welcome Back" : "Create Account"}</CardTitle>
                <CardDescription>
                  {isLogin ? "Sign in to your account to continue" : "Join our stokvel savings community"}
                </CardDescription>
              </motion.div>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <motion.div
                  initial={false}
                  animate={{ height: isLogin ? 0 : "auto", opacity: isLogin ? 0 : 1 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  style={{ overflow: "hidden" }}
                >
                  {!isLogin && (
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div>
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                          id="firstName"
                          value={form.firstName}
                          onChange={e => setForm({ ...form, firstName: e.target.value })}
                          placeholder="First name"
                          data-testid="input-first-name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                          id="lastName"
                          value={form.lastName}
                          onChange={e => setForm({ ...form, lastName: e.target.value })}
                          placeholder="Last name"
                          data-testid="input-last-name"
                        />
                      </div>
                    </div>
                  )}
                </motion.div>
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={form.email}
                    onChange={e => setForm({ ...form, email: e.target.value })}
                    placeholder="you@example.com"
                    data-testid="input-email"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={form.password}
                      onChange={e => setForm({ ...form, password: e.target.value })}
                      placeholder={isLogin ? "Enter your password" : "At least 6 characters"}
                      data-testid="input-password"
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0"
                      onClick={() => setShowPassword(!showPassword)}
                      data-testid="button-toggle-password"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}>
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isLoggingIn || isSigningUp}
                    data-testid="button-auth-submit"
                  >
                    {(isLoggingIn || isSigningUp) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    {isLogin ? "Sign In" : "Create Account"}
                  </Button>
                </motion.div>
              </form>

              <div className="mt-6 text-center text-sm">
                <span className="text-muted-foreground">
                  {isLogin ? "Don't have an account?" : "Already have an account?"}
                </span>{" "}
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-primary font-medium hover:underline"
                  data-testid="button-toggle-auth-mode"
                >
                  {isLogin ? "Sign Up" : "Sign In"}
                </button>
              </div>
            </CardContent>
          </Card>
        </ScaleIn>

        <FadeIn delay={0.5}>
          <p className="text-center text-xs text-muted-foreground mt-6">
            By continuing, you agree to our terms and privacy policy.
          </p>
        </FadeIn>
      </div>
    </div>
  );
}

function FadeIn({ children, delay = 0 }: { children: any; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4, delay }}
    >
      {children}
    </motion.div>
  );
}
