import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, BookOpen, Gift, Coins, Shield, Users, CheckCircle, ArrowRight, Star, Heart, TrendingUp, Sparkles } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { TIER_PRICES } from "@shared/constants";
import { FadeUp, FadeIn, ScaleIn, StaggerContainer, StaggerItem, FloatingElement, PulseGlow, motion } from "@/components/motion";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

const tierIcons: Record<string, any> = {
  primary: GraduationCap,
  high_school: BookOpen,
  cashback: Gift,
  cashback_1000: Coins,
};

export default function Landing() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      if ((user as any)?.member) {
        navigate("/dashboard");
      } else {
        navigate("/register");
      }
    } else {
      navigate("/auth");
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <section className="relative py-24 md:py-32 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-transparent to-accent/5 dark:from-primary/4 dark:to-accent/3" />
        <motion.div
          className="absolute top-20 left-10 w-32 h-32 bg-primary/5 rounded-full blur-3xl"
          animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-10 right-10 w-48 h-48 bg-accent/5 rounded-full blur-3xl"
          animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        />
        <div className="relative max-w-5xl mx-auto text-center">
          <FadeUp delay={0.1}>
            <Badge variant="secondary" className="mb-6" data-testid="badge-stokvel">
              <Sparkles className="h-3 w-3 mr-1" /> South Africa's Trusted Stokvel Platform
            </Badge>
          </FadeUp>
          <FadeUp delay={0.2}>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight" data-testid="text-hero-title">
              Invest in Your Child's
              <span className="text-primary block md:inline"> Future Today</span>
            </h1>
          </FadeUp>
          <FadeUp delay={0.35}>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-3xl mx-auto leading-relaxed" data-testid="text-hero-subtitle">
              Join Abangani NS Group and save from just R195/month. Your children receive brand-new school uniforms and complete stationery packs at the beginning of every school year.
            </p>
          </FadeUp>
          <FadeUp delay={0.5}>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                <Button size="lg" onClick={handleGetStarted} className="text-base px-8" data-testid="button-get-started">
                  Get Started Free <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                <Button size="lg" variant="outline" onClick={() => document.getElementById("tiers")?.scrollIntoView({ behavior: "smooth" })} className="text-base" data-testid="button-view-plans">
                  View Plans
                </Button>
              </motion.div>
            </div>
          </FadeUp>
          <FadeIn delay={0.7}>
            <div className="flex flex-wrap items-center justify-center gap-6 mt-10 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5"><CheckCircle className="h-4 w-4 text-primary" /> No hidden fees</div>
              <div className="flex items-center gap-1.5"><CheckCircle className="h-4 w-4 text-primary" /> Join any time</div>
              <div className="flex items-center gap-1.5"><CheckCircle className="h-4 w-4 text-primary" /> Trusted by parents</div>
            </div>
          </FadeIn>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <FadeUp>
            <div className="text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold mb-3">How It Works</h2>
              <p className="text-muted-foreground max-w-xl mx-auto">Three simple steps to secure your children's school needs</p>
            </div>
          </FadeUp>
          <StaggerContainer className="grid md:grid-cols-3 gap-8" staggerDelay={0.15}>
            {[
              { step: "1", title: "Create Your Account", desc: "Sign up for free and choose a subscription plan that suits your family's budget. Add your children's details.", icon: Users },
              { step: "2", title: "Contribute Monthly", desc: "Make your monthly contributions via bank transfer, online payment, or at Boxer, Pep, or Shoprite.", icon: TrendingUp },
              { step: "3", title: "Receive Benefits", desc: "At the start of each school year, your children receive brand-new uniforms and a complete stationery pack.", icon: Gift },
            ].map(item => (
              <StaggerItem key={item.step}>
                <div className="text-center">
                  <FloatingElement>
                    <div className="w-14 h-14 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4">
                      <item.icon className="h-6 w-6" />
                    </div>
                  </FloatingElement>
                  <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      <section id="tiers" className="py-16 px-4 bg-muted/30">
        <div className="max-w-5xl mx-auto">
          <FadeUp>
            <div className="text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold mb-3">Choose Your Plan</h2>
              <p className="text-muted-foreground max-w-xl mx-auto">Affordable plans designed for every family</p>
            </div>
          </FadeUp>
          <StaggerContainer className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6" staggerDelay={0.12}>
            {Object.entries(TIER_PRICES).map(([key, tier], idx) => {
              const Icon = tierIcons[key] || GraduationCap;
              const isPopular = key === "high_school";
              const isCashback = key.startsWith("cashback");
              return (
                <StaggerItem key={key}>
                  <motion.div whileHover={{ y: -6 }} transition={{ type: "spring", stiffness: 300, damping: 20 }}>
                    <Card className={isPopular ? "border-primary relative" : "relative"}>
                      {isPopular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                          <PulseGlow>
                            <Badge className="shadow-sm"><Star className="h-3 w-3 mr-1" /> Most Popular</Badge>
                          </PulseGlow>
                        </div>
                      )}
                      <CardHeader className="text-center pb-2 pt-6">
                        <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-3">
                          <Icon className="h-6 w-6" />
                        </div>
                        <CardTitle className="text-lg">{tier.name}</CardTitle>
                      </CardHeader>
                      <CardContent className="text-center">
                        <div className="mb-4">
                          <span className="text-4xl font-bold">R{tier.amount}</span>
                          <span className="text-muted-foreground">/month</span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-4">{tier.description}</p>
                        <div className="text-xs text-muted-foreground mb-4">
                          {isCashback
                            ? `R${tier.adminFee} admin fee | ${tier.cashbackPercent}% cashback`
                            : `Includes R${tier.adminFee} admin fee`}
                        </div>
                        <ul className="text-sm text-left space-y-3 mb-8">
                          {!isCashback && <li className="flex items-start gap-2"><CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" /> Full school uniforms</li>}
                          {!isCashback && <li className="flex items-start gap-2"><CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" /> Complete stationery pack</li>}
                          <li className="flex items-start gap-2"><CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" /> Payment tracking dashboard</li>
                          <li className="flex items-start gap-2"><CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" /> Flexible payment methods</li>
                          {isCashback && (
                            <li className="flex items-start gap-2"><CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" /> 50% cashback at year start</li>
                          )}
                        </ul>
                        <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
                          <Button className="w-full" variant={isPopular ? "default" : "outline"} onClick={handleGetStarted} data-testid={`button-select-${key}`}>
                            Get Started
                          </Button>
                        </motion.div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </StaggerItem>
              );
            })}
          </StaggerContainer>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <FadeUp>
            <div className="text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold mb-3">Why Parents Trust Us</h2>
              <p className="text-muted-foreground max-w-xl mx-auto">Built on the proven South African stokvel tradition</p>
            </div>
          </FadeUp>
          <StaggerContainer className="grid sm:grid-cols-2 md:grid-cols-4 gap-6" staggerDelay={0.1}>
            {[
              { icon: Shield, title: "Secure & Transparent", desc: "Track every payment in real-time" },
              { icon: Heart, title: "Community Driven", desc: "Parents saving together for their children" },
              { icon: TrendingUp, title: "Bulk Purchasing", desc: "Lower prices through group buying power" },
              { icon: Star, title: "Quality Guaranteed", desc: "Durable uniforms and complete stationery" },
            ].map(item => (
              <StaggerItem key={item.title}>
                <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300, damping: 20 }}>
                  <Card>
                    <CardContent className="p-6 text-center">
                      <item.icon className="h-8 w-8 text-primary mx-auto mb-3" />
                      <h3 className="font-semibold mb-1 text-sm">{item.title}</h3>
                      <p className="text-xs text-muted-foreground">{item.desc}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      <section className="py-20 px-4 bg-primary/5">
        <FadeUp>
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Give Your Children the Best Start?</h2>
            <p className="text-muted-foreground mb-8 text-lg">
              Join our growing community of parents. Sign up today and start saving for uniforms and stationery.
            </p>
            <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} className="inline-block">
              <Button size="lg" onClick={handleGetStarted} className="text-base px-8" data-testid="button-join-now">
                Join Abangani NS Group <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </FadeUp>
      </section>

      <Footer />
    </div>
  );
}
