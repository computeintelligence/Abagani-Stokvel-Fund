import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ThemeToggle } from "@/components/theme-toggle";
import { TIER_PRICES } from "@shared/constants";
import {
  Shield, Users, CreditCard, AlertTriangle, CheckCircle, X, Loader2,
  Clock, FileSpreadsheet, Download, FileText, Lock, LogOut, Truck,
  Edit, Eye
} from "lucide-react";
import { useState } from "react";
import { FadeUp, ScaleIn, StaggerContainer, StaggerItem, motion } from "@/components/motion";

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function AdminLogin({ onSuccess }: { onSuccess: () => void }) {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!code.trim()) return;
    setLoading(true);
    setError("");
    try {
      const res = await apiRequest("POST", "/api/admin/login", { code });
      const data = await res.json();
      if (data.authenticated) {
        onSuccess();
      }
    } catch (err: any) {
      setError("Invalid admin code. Access denied.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <FadeUp>
        <Card className="w-full max-w-sm">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
              <Lock className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Admin Access</CardTitle>
            <CardDescription>Enter the admin code to continue</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="admin-code">Admin Code</Label>
              <Input
                id="admin-code"
                type="password"
                value={code}
                onChange={e => setCode(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleLogin()}
                placeholder="Enter admin code"
                data-testid="input-admin-code"
              />
            </div>
            {error && <div className="text-sm text-destructive" data-testid="text-admin-error">{error}</div>}
            <Button
              onClick={handleLogin}
              disabled={loading || !code.trim()}
              className="w-full"
              data-testid="button-admin-login"
            >
              {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Shield className="h-4 w-4 mr-2" />}
              Authenticate
            </Button>
          </CardContent>
        </Card>
      </FadeUp>
    </div>
  );
}

function MemberEditDialog({ member, open, onClose }: { member: any; open: boolean; onClose: () => void }) {
  const { toast } = useToast();
  const [fullName, setFullName] = useState(member?.fullName || "");
  const [phone, setPhone] = useState(member?.phone || "");
  const [tier, setTier] = useState(member?.tier || "primary");
  const [isActive, setIsActive] = useState(member?.isActive ?? true);

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PUT", `/api/admin/members/${member.id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({ title: "Member Updated" });
      onClose();
    },
    onError: (error: Error) => {
      toast({ title: "Update Failed", description: error.message, variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={v => !v && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Member</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Full Name</Label>
            <Input value={fullName} onChange={e => setFullName(e.target.value)} data-testid="input-edit-name" />
          </div>
          <div>
            <Label>Phone</Label>
            <Input value={phone} onChange={e => setPhone(e.target.value)} data-testid="input-edit-phone" />
          </div>
          <div>
            <Label>Tier</Label>
            <Select value={tier} onValueChange={setTier}>
              <SelectTrigger data-testid="select-edit-tier">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="primary">Primary School (R195)</SelectItem>
                <SelectItem value="high_school">High School (R295)</SelectItem>
                <SelectItem value="cashback">Cashback R500</SelectItem>
                <SelectItem value="cashback_1000">Cashback R1000</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Label>Active Status</Label>
            <Button
              variant={isActive ? "default" : "destructive"}
              size="sm"
              onClick={() => setIsActive(!isActive)}
              data-testid="button-toggle-active"
            >
              {isActive ? "Active" : "Inactive"}
            </Button>
          </div>
          <Button
            onClick={() => updateMutation.mutate({
              fullName,
              phone,
              tier,
              monthlyAmount: TIER_PRICES[tier]?.amount || 195,
              isActive,
            })}
            disabled={updateMutation.isPending}
            className="w-full"
            data-testid="button-save-member"
          >
            {updateMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Admin() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [editMember, setEditMember] = useState<any>(null);

  const { data: session, isLoading: sessionLoading } = useQuery({
    queryKey: ["/api/admin/session"],
    queryFn: async () => {
      const res = await fetch("/api/admin/session", { credentials: "include" });
      return await res.json();
    },
  });

  const isAdmin = (session as any)?.authenticated === true;

  const { data: stats } = useQuery({
    queryKey: ["/api/admin/stats"],
    enabled: isAdmin,
  });

  const { data: allMembers, isLoading: membersLoading } = useQuery({
    queryKey: ["/api/admin/members"],
    enabled: isAdmin,
  });

  const { data: pendingPayments, isLoading: pendingLoading } = useQuery({
    queryKey: ["/api/admin/pending-payments"],
    enabled: isAdmin,
  });

  const { data: overdueMembers } = useQuery({
    queryKey: ["/api/admin/overdue"],
    enabled: isAdmin,
  });

  const { data: suppliers } = useQuery({
    queryKey: ["/api/admin/suppliers"],
    enabled: isAdmin,
  });

  const exportSheetsMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/export-sheets");
      return await res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Export Complete", description: `Backup saved: ${data.title}` });
      if (data.url) window.open(data.url, "_blank");
    },
    onError: (error: Error) => {
      toast({ title: "Export Failed", description: error.message, variant: "destructive" });
    },
  });

  const verifyMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("POST", `/api/admin/payments/${id}/verify`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pending-payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({ title: "Payment Updated" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const supplierStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("POST", `/api/admin/suppliers/${id}/status`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/suppliers"] });
      toast({ title: "Supplier Updated" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleLogout = async () => {
    await apiRequest("POST", "/api/admin/logout");
    queryClient.invalidateQueries({ queryKey: ["/api/admin/session"] });
  };

  const handleExportCSV = async () => {
    try {
      const res = await fetch("/api/admin/export-csv", { credentials: "include" });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `abangani_export_${new Date().toISOString().split("T")[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast({ title: "CSV Downloaded" });
    } catch {
      toast({ title: "CSV Export Failed", variant: "destructive" });
    }
  };

  const handleDownloadPDF = async (memberId: string, memberName: string) => {
    try {
      const res = await fetch(`/api/admin/members/${memberId}/pdf`, { credentials: "include" });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${memberName.replace(/\s+/g, "_")}_record.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      toast({ title: "PDF Download Failed", variant: "destructive" });
    }
  };

  if (sessionLoading) {
    return <div className="flex items-center justify-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  if (!isAdmin) {
    return <AdminLogin onSuccess={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/session"] })} />;
  }

  const s = stats as any;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 flex items-center justify-between gap-4 flex-wrap p-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          <span className="font-bold" data-testid="text-admin-brand">Admin Panel</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => exportSheetsMutation.mutate()} disabled={exportSheetsMutation.isPending} data-testid="button-export-sheets">
            {exportSheetsMutation.isPending ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <FileSpreadsheet className="h-4 w-4 mr-1" />}
            Sheets
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportCSV} data-testid="button-export-csv">
            <Download className="h-4 w-4 mr-1" /> CSV
          </Button>
          <ThemeToggle />
          <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-admin-logout">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <div className="max-w-5xl mx-auto p-4 space-y-6">
        {s && (
          <FadeUp>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <Users className="h-5 w-5 mx-auto mb-1 text-primary" />
                  <div className="text-2xl font-bold" data-testid="stat-total-members">{s.totalMembers}</div>
                  <div className="text-xs text-muted-foreground">Total Members</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <CheckCircle className="h-5 w-5 mx-auto mb-1 text-primary" />
                  <div className="text-2xl font-bold" data-testid="stat-active">{s.activeMembers}</div>
                  <div className="text-xs text-muted-foreground">Active</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <CreditCard className="h-5 w-5 mx-auto mb-1 text-primary" />
                  <div className="text-2xl font-bold" data-testid="stat-revenue">R{(s.totalRevenue || 0).toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">Total Revenue</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Clock className="h-5 w-5 mx-auto mb-1 text-accent-foreground" />
                  <div className="text-2xl font-bold" data-testid="stat-pending">{s.pendingPayments}</div>
                  <div className="text-xs text-muted-foreground">Pending</div>
                </CardContent>
              </Card>
            </div>
          </FadeUp>
        )}

        {s?.tierBreakdown && (
          <ScaleIn delay={0.1}>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Tier Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-6 flex-wrap">
                  {Object.entries(s.tierBreakdown).map(([key, count]: [string, any]) => (
                    <div key={key} className="flex items-center gap-2">
                      <Badge variant="secondary">{TIER_PRICES[key]?.name || key}</Badge>
                      <span className="font-bold">{count}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </ScaleIn>
        )}

        <Tabs defaultValue="pending">
          <TabsList className="flex-wrap">
            <TabsTrigger value="pending" data-testid="tab-pending">
              Pending {(pendingPayments as any[])?.length ? `(${(pendingPayments as any[]).length})` : ""}
            </TabsTrigger>
            <TabsTrigger value="members" data-testid="tab-members">Members</TabsTrigger>
            <TabsTrigger value="arrears" data-testid="tab-arrears">
              Arrears {(overdueMembers as any[])?.length ? `(${(overdueMembers as any[]).length})` : ""}
            </TabsTrigger>
            <TabsTrigger value="suppliers" data-testid="tab-suppliers">
              Suppliers {(suppliers as any[])?.length ? `(${(suppliers as any[]).length})` : ""}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-3 mt-4">
            {pendingLoading ? (
              <div className="flex justify-center p-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
            ) : (pendingPayments as any[])?.length === 0 ? (
              <Card><CardContent className="p-6 text-center text-muted-foreground">No pending payments to verify</CardContent></Card>
            ) : (
              <StaggerContainer staggerDelay={0.05}>
                {(pendingPayments as any[])?.map((p: any) => (
                  <StaggerItem key={p.id}>
                    <Card className="mb-3">
                      <CardContent className="flex items-center justify-between gap-4 flex-wrap p-4">
                        <div className="flex-1 min-w-0">
                          <div className="font-medium">{p.memberName}</div>
                          <div className="text-sm text-muted-foreground">
                            R{p.amount} - {MONTH_NAMES[(p.month || 1) - 1]} {p.year} via {p.method?.replace("_", " ")}
                          </div>
                          {p.reference && <div className="text-xs text-muted-foreground">Ref: {p.reference}</div>}
                          {p.proofUrl && (
                            <div className="text-xs mt-1">
                              <a href={p.proofUrl} target="_blank" rel="noopener noreferrer" className="text-primary underline flex items-center gap-1">
                                <Eye className="h-3 w-3" /> View Proof
                              </a>
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            onClick={() => verifyMutation.mutate({ id: p.id, status: "verified" })}
                            disabled={verifyMutation.isPending}
                            data-testid={`button-verify-${p.id}`}
                          >
                            <CheckCircle className="h-3.5 w-3.5 mr-1" /> Verify
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => verifyMutation.mutate({ id: p.id, status: "rejected" })}
                            disabled={verifyMutation.isPending}
                            data-testid={`button-reject-${p.id}`}
                          >
                            <X className="h-3.5 w-3.5 mr-1" /> Reject
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </TabsContent>

          <TabsContent value="members" className="space-y-3 mt-4">
            {membersLoading ? (
              <div className="flex justify-center p-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
            ) : (allMembers as any[])?.length === 0 ? (
              <Card><CardContent className="p-6 text-center text-muted-foreground">No members registered yet</CardContent></Card>
            ) : (
              <StaggerContainer staggerDelay={0.05}>
                {(allMembers as any[])?.map((m: any) => (
                  <StaggerItem key={m.id}>
                    <Card className="mb-3">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between gap-4 flex-wrap">
                          <div className="flex-1 min-w-0">
                            <div className="font-medium">{m.fullName}</div>
                            <div className="text-sm text-muted-foreground">{m.phone} | {m.trackingNumber}</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary">{TIER_PRICES[m.tier]?.name || m.tier}</Badge>
                            <Badge variant={m.isActive ? "default" : "destructive"}>{m.isActive ? "Active" : "Inactive"}</Badge>
                            <Button size="icon" variant="ghost" onClick={() => setEditMember(m)} data-testid={`button-edit-${m.id}`}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="icon" variant="ghost" onClick={() => handleDownloadPDF(m.id, m.fullName)} data-testid={`button-pdf-${m.id}`}>
                              <FileText className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        {m.children?.length > 0 && (
                          <div className="mt-2 text-sm text-muted-foreground">
                            Children: {m.children.map((c: any) => `${c.fullName} (${c.school}, ${c.grade})`).join(", ")}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </TabsContent>

          <TabsContent value="arrears" className="space-y-3 mt-4">
            {(overdueMembers as any[])?.length === 0 ? (
              <Card><CardContent className="p-6 text-center text-muted-foreground">No members in arrears</CardContent></Card>
            ) : (
              <StaggerContainer staggerDelay={0.05}>
                {(overdueMembers as any[])?.map((m: any) => (
                  <StaggerItem key={m.id}>
                    <Card className="mb-3">
                      <CardContent className="flex items-center justify-between gap-4 flex-wrap p-4">
                        <div className="flex items-center gap-3">
                          <AlertTriangle className="h-5 w-5 text-destructive shrink-0" />
                          <div>
                            <div className="font-medium">{m.fullName}</div>
                            <div className="text-sm text-muted-foreground">{m.trackingNumber} | R{m.monthlyAmount}/month</div>
                          </div>
                        </div>
                        <Badge variant="destructive">In Arrears</Badge>
                      </CardContent>
                    </Card>
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </TabsContent>

          <TabsContent value="suppliers" className="space-y-3 mt-4">
            {(suppliers as any[])?.length === 0 ? (
              <Card><CardContent className="p-6 text-center text-muted-foreground">No supplier applications yet</CardContent></Card>
            ) : (
              <StaggerContainer staggerDelay={0.05}>
                {(suppliers as any[])?.map((sup: any) => (
                  <StaggerItem key={sup.id}>
                    <Card className="mb-3">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between gap-4 flex-wrap">
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <Truck className="h-5 w-5 text-primary shrink-0" />
                            <div className="min-w-0">
                              <div className="font-medium truncate">{sup.businessName}</div>
                              <div className="text-sm text-muted-foreground truncate">
                                {sup.contactFirstName} {sup.contactLastName} | {sup.contactEmail}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {sup.city}, {sup.province} | {sup.businessType} | Products: {sup.productsOffered}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={sup.status === "approved" ? "default" : sup.status === "rejected" ? "destructive" : "secondary"}>
                              {sup.status}
                            </Badge>
                            {sup.status === "pending" && (
                              <>
                                <Button
                                  size="sm"
                                  onClick={() => supplierStatusMutation.mutate({ id: sup.id, status: "approved" })}
                                  disabled={supplierStatusMutation.isPending}
                                  data-testid={`button-approve-supplier-${sup.id}`}
                                >
                                  <CheckCircle className="h-3.5 w-3.5 mr-1" /> Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => supplierStatusMutation.mutate({ id: sup.id, status: "rejected" })}
                                  disabled={supplierStatusMutation.isPending}
                                  data-testid={`button-reject-supplier-${sup.id}`}
                                >
                                  <X className="h-3.5 w-3.5 mr-1" /> Reject
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {editMember && (
        <MemberEditDialog
          member={editMember}
          open={!!editMember}
          onClose={() => setEditMember(null)}
        />
      )}
    </div>
  );
}
