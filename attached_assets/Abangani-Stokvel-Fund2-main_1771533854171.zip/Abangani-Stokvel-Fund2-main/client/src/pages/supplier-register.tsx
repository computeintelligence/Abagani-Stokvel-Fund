import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, CheckCircle, Loader2, User, Building2, FileCheck } from "lucide-react";
import { FadeUp, ScaleIn, motion } from "@/components/motion";
import { AnimatePresence } from "framer-motion";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

const STEPS = ["Personal Info", "Business Info", "Agreements"];
const STEP_ICONS = [User, Building2, FileCheck];

const SA_PROVINCES = [
  "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal",
  "Limpopo", "Mpumalanga", "North West", "Northern Cape", "Western Cape"
];

const BUSINESS_TYPES = [
  "Sole Proprietor", "Partnership", "Close Corporation (CC)",
  "Private Company (Pty Ltd)", "Co-operative", "Other"
];

export default function SupplierRegister() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  const [personal, setPersonal] = useState({
    contactFirstName: "",
    contactLastName: "",
    contactEmail: "",
    contactPhone: "",
  });

  const [business, setBusiness] = useState({
    businessName: "",
    businessType: "",
    businessRegistrationNumber: "",
    businessAddress: "",
    city: "",
    province: "",
    productsOffered: "",
  });

  const [agreements, setAgreements] = useState({
    agreedToLowPrices: false,
    agreedToTerms: false,
  });

  const registerMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/suppliers/register", {
        ...personal,
        ...business,
        ...agreements,
      });
      return await res.json();
    },
    onSuccess: () => {
      setSubmitted(true);
      toast({ title: "Application Submitted!", description: "Check your email for a confirmation message." });
    },
    onError: (error: Error) => {
      const msg = error?.message?.includes(":") ? error.message.split(": ").slice(1).join(": ") : error?.message;
      toast({ title: "Submission Failed", description: msg, variant: "destructive" });
    },
  });

  const canNext = () => {
    if (step === 0) return personal.contactFirstName.trim() && personal.contactLastName.trim() && personal.contactEmail.trim() && personal.contactPhone.trim();
    if (step === 1) return business.businessName.trim() && business.businessType && business.businessAddress.trim() && business.city.trim() && business.province && business.productsOffered.trim();
    if (step === 2) return agreements.agreedToLowPrices && agreements.agreedToTerms;
    return false;
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center p-4">
          <ScaleIn><Card className="max-w-md w-full">
            <CardContent className="p-8 text-center">
              <CheckCircle className="h-16 w-16 text-primary mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">Application Submitted!</h2>
              <p className="text-muted-foreground mb-6">
                Thank you for your interest in becoming a supplier for Abangani NS Group.
                We will review your application and get back to you within 5-7 business days. A confirmation email has been sent to {personal.contactEmail}.
              </p>
              <Button onClick={() => navigate("/")} data-testid="button-back-home">
                Back to Home
              </Button>
            </CardContent>
          </Card></ScaleIn>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <div className="flex-1 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-1" data-testid="text-supplier-title">Register as a Supplier</h1>
            <p className="text-muted-foreground text-sm">Apply to become a local supplier for Abangani NS Group</p>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 flex-wrap mb-2">
              {STEPS.map((s, i) => {
                const Icon = STEP_ICONS[i];
                return (
                  <Badge key={s} variant={i === step ? "default" : i < step ? "secondary" : "outline"} data-testid={`badge-supplier-step-${i}`}>
                    {i < step ? <CheckCircle className="h-3 w-3 mr-1" /> : <Icon className="h-3 w-3 mr-1" />} {s}
                  </Badge>
                );
              })}
            </div>
            <Progress value={((step + 1) / STEPS.length) * 100} className="h-2" />
          </div>

          <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div key="sup-step-0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}><Card>
              <CardHeader>
                <CardTitle className="text-lg">Personal Information</CardTitle>
                <CardDescription>Your contact details as the business representative</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input id="firstName" value={personal.contactFirstName} onChange={e => setPersonal({ ...personal, contactFirstName: e.target.value })} placeholder="First name" data-testid="input-supplier-first-name" />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input id="lastName" value={personal.contactLastName} onChange={e => setPersonal({ ...personal, contactLastName: e.target.value })} placeholder="Last name" data-testid="input-supplier-last-name" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input id="email" type="email" value={personal.contactEmail} onChange={e => setPersonal({ ...personal, contactEmail: e.target.value })} placeholder="business@example.com" data-testid="input-supplier-email" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone *</Label>
                  <Input id="phone" value={personal.contactPhone} onChange={e => setPersonal({ ...personal, contactPhone: e.target.value })} placeholder="e.g. 071 234 5678" data-testid="input-supplier-phone" />
                </div>
              </CardContent>
            </Card></motion.div>
          )}

          {step === 1 && (
            <motion.div key="sup-step-1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}><Card>
              <CardHeader>
                <CardTitle className="text-lg">Business Information</CardTitle>
                <CardDescription>Tell us about your business and what you can supply</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="businessName">Business Name *</Label>
                  <Input id="businessName" value={business.businessName} onChange={e => setBusiness({ ...business, businessName: e.target.value })} placeholder="Your business name" data-testid="input-supplier-business-name" />
                </div>
                <div>
                  <Label htmlFor="businessType">Business Type *</Label>
                  <Select value={business.businessType} onValueChange={v => setBusiness({ ...business, businessType: v })}>
                    <SelectTrigger data-testid="select-supplier-business-type">
                      <SelectValue placeholder="Select business type" />
                    </SelectTrigger>
                    <SelectContent>
                      {BUSINESS_TYPES.map(t => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="regNumber">Business Registration Number (optional)</Label>
                  <Input id="regNumber" value={business.businessRegistrationNumber} onChange={e => setBusiness({ ...business, businessRegistrationNumber: e.target.value })} placeholder="e.g. 2024/123456/07" data-testid="input-supplier-reg-number" />
                </div>
                <div>
                  <Label htmlFor="businessAddress">Business Address *</Label>
                  <Input id="businessAddress" value={business.businessAddress} onChange={e => setBusiness({ ...business, businessAddress: e.target.value })} placeholder="Street address" data-testid="input-supplier-address" />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="city">City / Town *</Label>
                    <Input id="city" value={business.city} onChange={e => setBusiness({ ...business, city: e.target.value })} placeholder="City or town" data-testid="input-supplier-city" />
                  </div>
                  <div>
                    <Label htmlFor="province">Province *</Label>
                    <Select value={business.province} onValueChange={v => setBusiness({ ...business, province: v })}>
                      <SelectTrigger data-testid="select-supplier-province">
                        <SelectValue placeholder="Select province" />
                      </SelectTrigger>
                      <SelectContent>
                        {SA_PROVINCES.map(p => (
                          <SelectItem key={p} value={p}>{p}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="products">Products You Can Supply *</Label>
                  <Textarea id="products" value={business.productsOffered} onChange={e => setBusiness({ ...business, productsOffered: e.target.value })} placeholder="e.g. School uniforms, stationery, school shoes, school bags..." rows={3} data-testid="input-supplier-products" />
                </div>
              </CardContent>
            </Card></motion.div>
          )}

          {step === 2 && (
            <motion.div key="sup-step-2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}><Card>
              <CardHeader>
                <CardTitle className="text-lg">Agreements</CardTitle>
                <CardDescription>Please review and agree to the supplier terms</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="prose prose-sm dark:prose-invert max-h-48 overflow-y-auto bg-muted/30 rounded-md p-4">
                  <h4>Supplier Agreement - Abangani NS Group</h4>
                  <p>As a registered supplier for Abangani NS Group, I understand and agree to the following:</p>
                  <ul>
                    <li><strong>Competitive Pricing:</strong> I commit to supplying goods at prices significantly lower than standard retail prices, as agreed upon with Abangani NS Group.</li>
                    <li><strong>Quality Standards:</strong> All products supplied must meet acceptable quality standards suitable for school use.</li>
                    <li><strong>Timely Delivery:</strong> I agree to deliver all orders within the agreed timeframe, particularly before the start of the school year in January.</li>
                    <li><strong>Stock Availability:</strong> I will maintain adequate stock levels to fulfil orders placed by the group.</li>
                    <li><strong>Communication:</strong> I will maintain open and responsive communication with the group administrators.</li>
                    <li><strong>Compliance:</strong> My business complies with all relevant South African laws and regulations.</li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start gap-3 p-3 rounded-md bg-muted/30">
                    <Checkbox
                      id="lowPrices"
                      checked={agreements.agreedToLowPrices}
                      onCheckedChange={(checked) => setAgreements({ ...agreements, agreedToLowPrices: checked === true })}
                      data-testid="checkbox-low-prices"
                    />
                    <Label htmlFor="lowPrices" className="text-sm leading-tight cursor-pointer">
                      I agree to supply goods at competitive low prices as negotiated with Abangani NS Group, benefiting the community.
                    </Label>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-md bg-muted/30">
                    <Checkbox
                      id="terms"
                      checked={agreements.agreedToTerms}
                      onCheckedChange={(checked) => setAgreements({ ...agreements, agreedToTerms: checked === true })}
                      data-testid="checkbox-supplier-terms"
                    />
                    <Label htmlFor="terms" className="text-sm leading-tight cursor-pointer">
                      I have read and agree to the Abangani NS Group supplier agreement and all terms outlined above.
                    </Label>
                  </div>
                </div>
              </CardContent>
            </Card></motion.div>
          )}
          </AnimatePresence>

          <div className="flex justify-between gap-4 mt-6">
            <Button variant="outline" onClick={() => step > 0 ? setStep(step - 1) : navigate("/")} data-testid="button-supplier-prev">
              <ArrowLeft className="h-4 w-4 mr-2" /> {step > 0 ? "Previous" : "Cancel"}
            </Button>
            {step < STEPS.length - 1 ? (
              <Button onClick={() => setStep(step + 1)} disabled={!canNext()} data-testid="button-supplier-next">
                Next <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            ) : (
              <Button onClick={() => registerMutation.mutate()} disabled={!canNext() || registerMutation.isPending} data-testid="button-supplier-submit">
                {registerMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                Submit Application
              </Button>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
