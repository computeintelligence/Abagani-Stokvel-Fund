import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Shield, Heart, Users, Target, BookOpen, Award, ArrowRight } from "lucide-react";
import { FadeUp, ScaleIn, StaggerContainer, StaggerItem } from "@/components/motion";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

export default function About() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <section className="py-16 px-4">
        <FadeUp>
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-about-title">About Abangani NS Group</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Abangani means "friends" in isiZulu. We are a community of parents united by a single goal: ensuring every child starts the school year fully prepared with uniforms and stationery.
            </p>
          </div>
        </FadeUp>
      </section>

      <section className="py-12 px-4 bg-muted/30">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
              <p className="text-muted-foreground mb-4">
                We believe that no child should start school without the proper tools and attire. Through our stokvel savings model, parents contribute a manageable monthly amount that collectively provides for every child in the group.
              </p>
              <p className="text-muted-foreground">
                By pooling our resources, we leverage bulk purchasing power to supply quality school uniforms and complete stationery packs at prices far below retail. This is the power of community.
              </p>
            </div>
            <StaggerContainer className="grid grid-cols-2 gap-4" staggerDelay={0.1}>
              <StaggerItem><Card>
                <CardContent className="p-6 text-center">
                  <Heart className="h-8 w-8 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-1">Community First</h3>
                  <p className="text-sm text-muted-foreground">Built on trust, transparency, and mutual support</p>
                </CardContent>
              </Card></StaggerItem>
              <StaggerItem><Card>
                <CardContent className="p-6 text-center">
                  <Target className="h-8 w-8 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-1">Clear Goals</h3>
                  <p className="text-sm text-muted-foreground">Every rand saved goes towards your children</p>
                </CardContent>
              </Card></StaggerItem>
              <StaggerItem><Card>
                <CardContent className="p-6 text-center">
                  <BookOpen className="h-8 w-8 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-1">Education</h3>
                  <p className="text-sm text-muted-foreground">Empowering learners to start school prepared</p>
                </CardContent>
              </Card></StaggerItem>
              <StaggerItem><Card>
                <CardContent className="p-6 text-center">
                  <Award className="h-8 w-8 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-1">Quality</h3>
                  <p className="text-sm text-muted-foreground">Durable uniforms and complete stationery packs</p>
                </CardContent>
              </Card></StaggerItem>
            </StaggerContainer>
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <FadeUp><h2 className="text-2xl font-bold text-center mb-8">How Our Stokvel Works</h2></FadeUp>
          <StaggerContainer className="space-y-6" staggerDelay={0.12}>
            {[
              { step: "1", title: "Register & Choose a Plan", desc: "Select from Primary School (R195/mo), High School (R295/mo), Cashback R500/mo, or Cashback R1000/mo plans based on your needs." },
              { step: "2", title: "Make Monthly Contributions", desc: "Pay your monthly contribution via bank transfer, online payment, or at participating retailers like Boxer, Pep, and Shoprite." },
              { step: "3", title: "Mid-Year Joiners Welcome", desc: "If you join after January, you simply pay the catch-up amount for the months already passed, then continue monthly." },
              { step: "4", title: "January Distribution", desc: "At the beginning of each school year, your children receive brand-new school uniforms and a full stationery pack." },
            ].map(item => (
              <StaggerItem key={item.step}>
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-lg font-bold shrink-0">{item.step}</div>
                  <div>
                    <h3 className="font-semibold mb-1">{item.title}</h3>
                    <p className="text-muted-foreground text-sm">{item.desc}</p>
                  </div>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      <section className="py-16 px-4 bg-primary/5">
        <ScaleIn>
        <div className="max-w-3xl mx-auto text-center">
          <Users className="h-10 w-10 mx-auto mb-4 text-primary" />
          <h2 className="text-2xl font-bold mb-4">Join Our Growing Family</h2>
          <p className="text-muted-foreground mb-6">
            Parents across South Africa are discovering the power of saving together. Be part of a community that puts children first.
          </p>
          <Button size="lg" onClick={() => navigate("/auth")} data-testid="button-join-about">
            Get Started Today <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
        </ScaleIn>
      </section>

      <Footer />
    </div>
  );
}
